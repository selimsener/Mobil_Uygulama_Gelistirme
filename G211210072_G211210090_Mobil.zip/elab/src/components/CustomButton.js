// components/CustomButton.js
import React from "react";
import { TouchableOpacity, Text, StyleSheet } from "react-native";

const CustomButton = ({ title, onPress, disabled=false }) => {
    return (
        <TouchableOpacity
            style={[styles.button, disabled && {opacity:0.5}]}
            onPress={onPress}
            disabled={disabled}
        >
            <Text style={styles.buttonText}>{title}</Text>
        </TouchableOpacity>
    );
};

export default CustomButton;

const styles = StyleSheet.create({
    button: {
        backgroundColor:"#007BFF",
        padding:15,
        borderRadius:5,
        marginVertical:10,
        alignItems:'center'
    },
    buttonText: {
        color:"#fff",
        fontWeight:'bold'
    }
});
