// components/CustomInput.js
import React from "react";
import { TextInput, StyleSheet, View, Text } from "react-native";

const CustomInput = ({ label, value, onChangeText, placeholder, secureTextEntry=false, keyboardType='default' }) => {
    return (
        <View style={styles.container}>
            {label && <Text style={styles.label}>{label}</Text>}
            <TextInput
                style={styles.input}
                value={value}
                onChangeText={onChangeText}
                placeholder={placeholder}
                secureTextEntry={secureTextEntry}
                keyboardType={keyboardType}
            />
        </View>
    );
};

export default CustomInput;

const styles = StyleSheet.create({
    container: {
        marginVertical: 8
    },
    label: {
        marginBottom: 4,
        fontWeight: '600'
    },
    input: {
        borderWidth:1,
        borderColor:"#ccc",
        borderRadius:5,
        padding:10
    }
});
