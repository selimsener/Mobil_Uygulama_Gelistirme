// components/DatePickerInput.js
import React, { useState } from 'react';
import { View, TouchableOpacity, Text, StyleSheet, Platform } from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import Ionicons from 'react-native-vector-icons/Ionicons';

const DatePickerInput = ({ label, date, setDate }) => {
    const [show, setShow] = useState(false);

    const onChange = (event, selectedDate) => {
        setShow(false);
        if (event.type === 'set' && selectedDate) {
            setDate(selectedDate);
        }
    };

    return (
        <View style={styles.container}>
            {label && <Text style={styles.label}>{label}</Text>}
            <TouchableOpacity style={styles.iconButton} onPress={() => setShow(true)}>
                <Ionicons
                    name="calendar"
                    size={20}
                    color="#fff"
                    style={{ marginRight: 5 }}
                />
                <Text style={styles.iconButtonText}>
                    {date ? date.toLocaleDateString() : 'Seçiniz'}
                </Text>
            </TouchableOpacity>
            {show && (
                <DateTimePicker
                    value={date || new Date()}
                    mode="date"
                    display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                    onChange={onChange}
                    maximumDate={new Date()}
                />
            )}
        </View>
    );
};

export default DatePickerInput;

const styles = StyleSheet.create({
    container: {
        marginVertical: 10,
    },
    label: {
        marginBottom: 6,
        fontSize: 16,
        fontWeight: '600',
        color: '#333',
    },
    iconButton: {
        flexDirection: 'row',
        backgroundColor: '#4CAF50',
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 10,
        borderRadius: 5,
        marginBottom: 15,
    },
    iconButtonText: {
        color: '#fff',
        fontSize: 15,
        flexShrink: 1,
    },
});
