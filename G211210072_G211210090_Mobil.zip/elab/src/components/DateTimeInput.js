// components/DateTimeInput.js
import React, { useState } from 'react';
import { View, TouchableOpacity, Text, StyleSheet, Platform } from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import Ionicons from 'react-native-vector-icons/Ionicons';

const DateTimeInput = ({ label, dateTime, setDateTime, mode = 'datetime' }) => {
    const [showPicker, setShowPicker] = useState(false);

    const onChange = (event, selectedDate) => {
        setShowPicker(false);
        if (event.type === 'set' && selectedDate) {
            setDateTime(selectedDate);
        }
    };

    const displayValue = dateTime
        ? mode === 'date'
            ? dateTime.toLocaleDateString()
            : mode === 'time'
                ? dateTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                : dateTime.toLocaleString()
        : 'Seçiniz';

    return (
        <View style={styles.container}>
            {label && <Text style={styles.label}>{label}</Text>}
            <TouchableOpacity style={styles.iconButton} onPress={() => setShowPicker(true)}>
                <Ionicons
                    name={mode === 'date' ? "calendar" : "time"}
                    size={20}
                    color="#fff"
                    style={{ marginRight: 5 }}
                />
                <Text style={styles.iconButtonText}>
                    {displayValue}
                </Text>
                <Ionicons
                    name="chevron-down"
                    size={20}
                    color="#fff"
                />
            </TouchableOpacity>
            {showPicker && (
                <DateTimePicker
                    value={dateTime || new Date()}
                    mode={mode}
                    display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                    onChange={onChange}
                    maximumDate={new Date()}
                />
            )}
        </View>
    );
};

export default DateTimeInput;

const styles = StyleSheet.create({
    container: {
        marginVertical: 10,
    },
    label: {
        marginBottom: 6,
        fontSize: 16,
        fontWeight: '600',
        color: '#333',
    },
    iconButton: {
        flexDirection: 'row',
        backgroundColor: '#1f85ff',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingVertical: 10,
        paddingHorizontal: 15,
        borderRadius: 5,
    },
    iconButtonText: {
        color: '#fff',
        fontSize: 15,
        flex: 1,
    },
});
