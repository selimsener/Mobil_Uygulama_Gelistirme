// ./screens/Doctor/GuideDetailScreen.js
import React, { useEffect, useState } from 'react';
import { View, Text, Button, StyleSheet, FlatList, Alert, TouchableOpacity } from 'react-native';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { db } from '../../firebase';
import Ionicons from '@expo/vector-icons/Ionicons';

const GuideDetailScreen = ({ route, navigation }) => {
    const { guideId } = route.params;
    const [guide, setGuide] = useState(null);

    const fetchGuide = async () => {
        const docRef = doc(db, 'guides', guideId);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
            setGuide({ id: docSnap.id, ...docSnap.data() });
        } else {
            Alert.alert('Hata', 'Klavuz bulunamadı');
            navigation.goBack();
        }
    };

    const confirmRemoveTestType = (testTypeName) => {
        Alert.alert(
            'Test Tipi Silme',
            `${testTypeName} test tipini silmek istediğinize emin misiniz?`,
            [
                { text: 'İptal', style: 'cancel' },
                {
                    text: 'Sil',
                    style: 'destructive',
                    onPress: () => removeTestType(testTypeName),
                },
            ]
        );
    };

    const removeTestType = async (testTypeName) => {
        if (!guide) return;
        const filtered = guide.testTypes.filter(tt => tt.name !== testTypeName);
        const docRef = doc(db, 'guides', guide.id);
        await updateDoc(docRef, { testTypes: filtered });
        setGuide({ ...guide, testTypes: filtered });
    };

    useEffect(() => {
        const unsubscribe = navigation.addListener('focus', fetchGuide);
        return unsubscribe;
    }, [navigation]);

    if (!guide) return null;

    return (
        <View style={styles.container}>
            <View style={styles.guideHeader}>
                <Ionicons name="book-outline" size={24} color="#333" style={styles.headerIcon} />
                <Text style={styles.title}>{guide.name}</Text>
            </View>
            <Text style={styles.desc}>{guide.description}</Text>
            <Text style={styles.unit}>Birim: {guide.unit}</Text>
            <Text style={styles.unit}>Tipi: {guide.type}</Text>

            <View style={styles.section}>
                <View style={styles.sectionHeader}>
                    <Text style={styles.sectionTitle}>Test Tipleri</Text>
                    <Button
                        title="Test Tipi Ekle"
                        onPress={() => navigation.navigate('AddTestType', { guideId: guide.id })}
                    />
                </View>

                <FlatList
                    data={guide.testTypes}
                    keyExtractor={(item) => item.name}
                    ListEmptyComponent={<Text style={styles.empty}>Hiç test tipi yok.</Text>}
                    renderItem={({ item }) => (
                        <View style={styles.testTypeRow}>
                            <View style={styles.testTypeInfo}>
                                <Ionicons name="flask-outline" size={18} color="#333" style={styles.testIcon} />
                                <Text style={styles.testTypeName}>{item.name}</Text>
                            </View>
                            <View style={styles.testTypeActions}>
                                <Button
                                    title="Yaş Grupları"
                                    onPress={() =>
                                        navigation.navigate('TestTypeDetail', {
                                            guideId: guide.id,
                                            testTypeName: item.name,
                                        })
                                    }
                                    color="#007BFF"
                                />
                                <Button
                                    title="Sil"
                                    color="#F44336"
                                    onPress={() => confirmRemoveTestType(item.name)}
                                />
                            </View>
                        </View>
                    )}
                />
            </View>
        </View>
    );
};

export default GuideDetailScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 16,
        backgroundColor: '#f5f5f5',
    },
    guideHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 15,
    },
    headerIcon: {
        marginRight: 8,
    },
    title: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#333',
    },
    desc: {
        fontSize: 14,
        marginBottom: 5,
        color: '#555',
    },
    unit: {
        fontSize: 14,
        marginBottom: 5,
        color: '#777',
    },
    section: {
        marginTop: 20,
        flex: 1,
    },
    sectionHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 10,
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#333',
    },
    empty: {
        textAlign: 'center',
        marginTop: 10,
        color: '#888',
    },
    testTypeRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        backgroundColor: '#fff',
        padding: 12,
        borderRadius: 8,
        marginBottom: 10,
        elevation: 1,
    },
    testTypeInfo: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    testIcon: {
        marginRight: 5,
    },
    testTypeName: {
        fontSize: 16,
        color: '#333',
        fontWeight: 'bold',
    },
    testTypeActions: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
    },
});
