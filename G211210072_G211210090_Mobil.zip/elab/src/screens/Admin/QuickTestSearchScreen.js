// QuickTestSearchScreen.js

import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    TextInput,
    StyleSheet,
    ActivityIndicator,
    Alert,
    ScrollView,
    TouchableOpacity,
} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../../firebase';

// Helper functions: parseAgeRange, isRangeWithin
export const parseAgeRange = (ageRangeStr) => {
    if (!ageRangeStr) return null;

    ageRangeStr = ageRangeStr.trim().toLowerCase();

    if (ageRangeStr.endsWith('+')) {
        const min = parseInt(ageRangeStr.slice(0, -1), 10);
        return { min, max: Infinity, type: 'min+' };
    }

    const rangeParts = ageRangeStr.split('-').map((part) => parseInt(part, 10));
    if (rangeParts.length === 2 && !isNaN(rangeParts[0]) && !isNaN(rangeParts[1])) {
        const [min, max] = rangeParts;
        return { min, max, type: 'range' };
    }

    return null;
};

export const isRangeWithin = (userRange, guideRange) => {
    if (!userRange || !guideRange) return false;
    // Check if user's range fully encompasses the guide's range
    return userRange.min <= guideRange.min && userRange.max >= guideRange.max;
};

// Test Types
export const TEST_TYPES = [
    'IgA',
    'IgM',
    'IgG',
    'IgG1',
    'IgG2',
    'IgG3',
    'IgG4',
];

// Status Styling
const getStatusStyle = (status) => {
    switch (status) {
        case 'Yüksek':
            return { color: '#F44336', icon: 'arrow-up-circle' };
        case 'Normal':
            return { color: '#4CAF50', icon: 'checkmark-circle' };
        case 'Düşük':
            return { color: '#FF9800', icon: 'arrow-down-circle' };
        default:
            return { color: '#555', icon: 'help-circle' };
    }
};

const QuickTestSearchScreen = () => {
    const [ageRange, setAgeRange] = useState('');
    const [testValues, setTestValues] = useState({});
    const [loading, setLoading] = useState(false);
    const [results, setResults] = useState([]);

    useEffect(() => {
        const initValues = {};
        TEST_TYPES.forEach((t) => {
            initValues[t] = '';
        });
        setTestValues(initValues);
    }, []);

    // Convert g/L to mg/L if needed
    const convertToGuideUnit = (value, guideUnit) => {
        if (guideUnit === 'mg/L') return value * 1000;
        return value;
    };

    // Convert g/L to mg/L for display
    const toMgL = (valueInGL) => {
        const val = parseFloat(valueInGL);
        if (isNaN(val)) return '';
        return (val * 1000).toFixed(2);
    };

    const handleSearch = async () => {
        // Validate age range
        const userRange = ageRange ? parseAgeRange(ageRange) : null;
        if (ageRange && !userRange) {
            Alert.alert('Hata', 'Geçerli bir yaş aralığı giriniz (Örn: 10-20 veya 18+).');
            return;
        }

        setLoading(true);
        setResults([]);

        try {
            // Fetch guides from Firestore
            const guidesSnap = await getDocs(collection(db, 'guides'));
            const guides = guidesSnap.docs.map((doc) => ({
                id: doc.id,
                ...doc.data(),
            }));

            const finalResults = [];

            // Build results for each test type
            TEST_TYPES.forEach((testType) => {
                const inputValStr = testValues[testType];
                const parsedVal = parseFloat(inputValStr);
                if (isNaN(parsedVal)) return; // Skip invalid/empty values

                // Group by guides
                const guideMap = {};

                guides.forEach((guide) => {
                    const test = Array.isArray(guide.testTypes)
                        ? guide.testTypes.find((t) => t.name === testType)
                        : null;
                    if (!test) return;

                    const filteredGroups = Array.isArray(test.ageGroups)
                        ? test.ageGroups.filter((ag) => {
                            if (!userRange) return true;
                            const guideRange = parseAgeRange(ag.ageRange);
                            return isRangeWithin(userRange, guideRange);
                        })
                        : [];

                    if (filteredGroups.length === 0) return;

                    filteredGroups.forEach((group) => {
                        const { referenceMin, referenceMax } = group;
                        const guideUnit = guide.unit || 'g/L';
                        const convertedVal = convertToGuideUnit(parsedVal, guideUnit);

                        let status = 'Normal';
                        if (convertedVal < referenceMin) status = 'Düşük';
                        else if (convertedVal > referenceMax) status = 'Yüksek';

                        if (!guideMap[guide.name]) {
                            guideMap[guide.name] = [];
                        }

                        guideMap[guide.name].push({
                            id: `${guide.name}-${group.ageRange}-${testType}-${Math.random()}`,
                            ageRange: group.ageRange,
                            referenceMin: referenceMin.toFixed(2),
                            referenceMax: referenceMax.toFixed(2),
                            unit: guideUnit,
                            status,
                        });
                    });
                });

                // Convert guideMap to array
                const guideEntries = Object.entries(guideMap); // [ [guideName, array], [guideName2, array2], ...]

                if (guideEntries.length > 0) {
                    finalResults.push({
                        testType,
                        inputVal: parsedVal.toFixed(2),
                        inputValMgL: toMgL(parsedVal.toFixed(2)),
                        guides: guideEntries.map(([guideName, arr]) => ({
                            guideName,
                            data: arr, // each guide's ageGroup data
                        })),
                    });
                }
            });

            setResults(finalResults);
        } catch (error) {
            console.error('Search Error:', error);
            Alert.alert('Hata', 'Arama sırasında bir hata oluştu.');
        } finally {
            setLoading(false);
        }
    };

    const handleClearAll = () => {
        const cleared = {};
        TEST_TYPES.forEach((t) => {
            cleared[t] = '';
        });
        setTestValues(cleared);
        setAgeRange('');
        setResults([]);
    };

    return (
        <ScrollView contentContainerStyle={styles.container}>
            <Text style={styles.title}>Hızlı Tetkik Arama</Text>

            <Text style={styles.label}>Yaş Aralığı (Opsiyonel)</Text>
            <TextInput
                placeholder="Örn: 10-20 veya 18+"
                value={ageRange}
                onChangeText={setAgeRange}
                style={styles.input}
            />

            <Text style={styles.label}>Tetkik Değerleri</Text>
            {TEST_TYPES.map((type) => (
                <View key={type} style={styles.testRow}>
                    <Text style={styles.testName}>{type}:</Text>
                    <TextInput
                        placeholder={`Örn. ${type} değeri (g/L)`}
                        value={testValues[type]}
                        onChangeText={(val) => setTestValues({ ...testValues, [type]: val })}
                        style={styles.testInput}
                        keyboardType="numeric"
                    />
                </View>
            ))}

            {/* Buttons */}
            <View style={styles.buttonRow}>
                <TouchableOpacity
                    style={[styles.searchButton, loading && styles.searchButtonDisabled]}
                    onPress={handleSearch}
                    disabled={loading}
                >
                    {loading ? (
                        <>
                            <ActivityIndicator size="small" color="#fff" style={{ marginRight: 5 }} />
                            <Text style={styles.searchButtonText}>Aranıyor...</Text>
                        </>
                    ) : (
                        <Text style={styles.searchButtonText}>Ara</Text>
                    )}
                </TouchableOpacity>

                <TouchableOpacity style={styles.clearButton} onPress={handleClearAll}>
                    <Text style={styles.clearButtonText}>Tüm Değerleri Sil</Text>
                </TouchableOpacity>
            </View>

            {/* No Results */}
            {results.length === 0 && !loading ? (
                <Text style={styles.empty}>Sonuç bulunamadı veya henüz arama yapılmadı.</Text>
            ) : null}

            {/* Cards */}
            {results.map((res) => (
                <View key={res.testType} style={styles.card}>
                    {/* Card Header: Test Type and Entered Values in g/L and mg/L */}
                    <Text style={styles.cardTitle}>
                        {res.testType} - Girilen Değer: {res.inputVal} g/L {'  '}
                        {res.inputValMgL} mg/L
                    </Text>

                    {/* Guides */}
                    {res.guides?.map((gEntry, idx) => {
                        const { guideName, data } = gEntry;

                        return (
                            <View key={guideName}>
                                {/* Guide Header */}
                                <View style={styles.guideHeaderContainer}>
                                    <Text style={styles.guideHeader}>{guideName}</Text>
                                </View>

                                {/* Age Groups */}
                                {data?.map((item, subIndex) => {
                                    const { color, icon } = getStatusStyle(item.status);

                                    // Determine if this is the last item
                                    const isLastItem = subIndex === data.length - 1;

                                    return (
                                        <View key={item.id} style={styles.groupContainer}>
                                            <Text style={styles.cardSubtitle}>
                                                Yaş Aralığı: {item.ageRange}
                                            </Text>
                                            <Text style={styles.cardText}>
                                                Referans Aralık: {item.referenceMin} - {item.referenceMax} {item.unit}
                                            </Text>

                                            {/* Status */}
                                            <View style={styles.statusRow}>
                                                <Ionicons
                                                    name={icon}
                                                    size={18}
                                                    color={color}
                                                    style={{ marginRight: 5 }}
                                                />
                                                <Text style={[styles.cardStatus, { color }]}>
                                                    {item.status}
                                                </Text>
                                            </View>

                                            {/* Small Divider between age groups */}
                                            {!isLastItem && (
                                                <View style={styles.smallDivider} />
                                            )}
                                        </View>
                                    );
                                })}
                            </View>
                        );
                    })}
                </View>
            ))}
        </ScrollView>
    );
};

// Move styles outside the component
const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        paddingHorizontal: 16,
        paddingTop: 20,
        paddingBottom: 40,
        backgroundColor: '#f9f9f9',
    },
    title: {
        fontSize: 22,
        fontWeight: 'bold',
        marginBottom: 20,
        textAlign: 'center',
        color: '#333',
    },
    label: {
        fontSize: 16,
        fontWeight: '600',
        marginBottom: 8,
        color: '#555',
    },
    input: {
        borderWidth: 1,
        borderColor: '#ccc',
        padding: 12,
        borderRadius: 8,
        marginBottom: 20,
        backgroundColor: '#fff',
        fontSize: 16,
        color: '#333',
    },
    testRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 12,
    },
    testName: {
        width: 80,
        fontWeight: 'bold',
        color: '#333',
    },
    testInput: {
        flex: 1,
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 8,
        paddingHorizontal: 10,
        paddingVertical: 8,
        backgroundColor: '#fff',
        fontSize: 16,
        color: '#333',
    },
    buttonRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 20,
    },
    searchButton: {
        flex: 0.48,
        flexDirection: 'row',
        backgroundColor: '#2196F3',
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 12,
        borderRadius: 5,
    },
    searchButtonDisabled: {
        backgroundColor: '#90caf9',
    },
    searchButtonText: {
        color: '#fff',
        fontSize: 16,
        fontWeight: '600',
    },
    clearButton: {
        flex: 0.48,
        backgroundColor: '#f44336',
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 12,
        borderRadius: 5,
    },
    clearButtonText: {
        color: '#fff',
        fontSize: 16,
        fontWeight: '600',
    },
    empty: {
        textAlign: 'center',
        color: '#888',
        fontSize: 16,
        marginTop: 20,
    },
    card: {
        backgroundColor: '#fff',
        borderRadius: 8,
        padding: 15,
        marginBottom: 15,
        borderWidth: 1,
        borderColor: '#ddd',
        // Shadow
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 3,
    },
    cardTitle: {
        fontSize: 15,
        fontWeight: '700',
        marginBottom: 10,
        color: '#333',
    },
    guideHeaderContainer: {
        paddingVertical: 8,
        backgroundColor: '#c5cae9',
        borderRadius: 5,
        marginBottom: 10,
        marginTop: 5,
    },
    guideHeader: {
        fontSize: 15,
        fontWeight: '700',
        textAlign: 'center',
        color: '#333',
    },
    groupContainer: {
        marginBottom: 12,
    },
    cardSubtitle: {
        fontSize: 14,
        marginBottom: 5,
        fontWeight: '600',
        color: '#555',
    },
    cardText: {
        fontSize: 14,
        marginBottom: 5,
        color: '#555',
    },
    statusRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 4,
    },
    cardStatus: {
        fontWeight: '700',
        fontSize: 14,
    },
    // Divider Styles
    smallDivider: {
        height: 1,
        backgroundColor: '#ddd',
        marginVertical: 6,
    },
});

export default QuickTestSearchScreen;
