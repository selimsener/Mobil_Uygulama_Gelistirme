// screens/AddTestResultScreen.js
import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    TextInput,
    Button,
    StyleSheet,
    Alert,
    ScrollView,
    ActivityIndicator,
} from 'react-native';
import { doc, getDoc, getDocs, collection, addDoc } from 'firebase/firestore';
import { db } from '../../firebase';
import { calculateAgeInMonths } from '../../utils/ageCalculator';
import { isAgeInRange } from '../../utils/ageRangeEvaluator';
import { TEST_TYPES } from '../../constants/testTypes';
import Icon from 'react-native-vector-icons/FontAwesome';
import DateTimeInput from '../../components/DateTimeInput';
import DatePickerInput from '../../components/DatePickerInput';

const AddTestResultScreen = ({ route, navigation }) => {
    const { patientId } = route.params;
    const [patient, setPatient] = useState(null);
    const [date, setDate] = useState(new Date());
    const [time, setTime] = useState(new Date());
    const [testValues, setTestValues] = useState({});
    const [loading, setLoading] = useState(false);

    // Fetch patient information
    const fetchPatient = async () => {
        try {
            const patientDoc = doc(db, 'users', patientId);
            const snap = await getDoc(patientDoc);
            if (!snap.exists()) {
                Alert.alert('Hata', 'Hasta bulunamadı.');
                navigation.goBack();
                return;
            }
            setPatient({ id: snap.id, ...snap.data() });
        } catch (error) {
            console.error('Hasta bilgisi alınırken hata:', error);
            Alert.alert('Hata', 'Hasta bilgisi alınamadı.');
        }
    };

    useEffect(() => {
        fetchPatient();
    }, []);

    const convertUnits = (value, fromUnit, toUnit) => {
        if (fromUnit === toUnit) return value;
        if (fromUnit === "g/L" && toUnit === "mg/L") {
            return value * 1000;
        }
        if (fromUnit === "mg/L" && toUnit === "g/L") {
            return value / 1000;
        }
        return value;
    };

    const saveTestResults = async () => {
        if (!patient) return;

        const ageInMonths = calculateAgeInMonths(patient.birthDate);

        setLoading(true);

        try {
            const guidesSnap = await getDocs(collection(db, 'guides'));
            const guides = guidesSnap.docs.map((doc) => ({ id: doc.id, ...doc.data() }));

            const combinedDateTime = new Date(
                date.getFullYear(),
                date.getMonth(),
                date.getDate(),
                time.getHours(),
                time.getMinutes(),
                time.getSeconds()
            );

            const finalResults = TEST_TYPES.map((testName) => {
                const inputValue = parseFloat(testValues[testName]);
                if (isNaN(inputValue)) return null;

                const evaluations = [];

                guides.forEach((guide) => {
                    guide.testTypes.forEach((testType) => {
                        if (testType.name === testName) {
                            const ageGroup = testType.ageGroups.find((ag) =>
                                isAgeInRange(ageInMonths, ag.ageRange)
                            );

                            if (ageGroup) {
                                const convertedValue = convertUnits(
                                    inputValue,
                                    "g/L",
                                    guide.unit || "mg/L"
                                );

                                const { referenceMin, referenceMax } = ageGroup;
                                let status = "Normal";
                                if (convertedValue < referenceMin) status = "Düşük";
                                else if (convertedValue > referenceMax) status = "Yüksek";

                                evaluations.push({
                                    guideName: guide.name || "Bilinmeyen Klavuz",
                                    referenceMin,
                                    referenceMax,
                                    status,
                                    unit: guide.unit || "mg/L",
                                });
                            }
                        }
                    });
                });

                return {
                    name: testName,
                    value: inputValue,
                    evaluations,
                };
            }).filter(Boolean);

            const resultsRef = collection(db, 'users', patientId, 'results');
            await addDoc(resultsRef, {
                date: combinedDateTime,
                tests: finalResults,
            });

            Alert.alert('Başarılı', 'Tahlil sonuçları başarıyla kaydedildi.');
            navigation.goBack();
        } catch (error) {
            console.error('Tahlil sonuçları kaydedilirken hata:', error);
            Alert.alert('Hata', 'Tahlil sonuçları kaydedilemedi.');
        } finally {
            setLoading(false);
        }
    };

    const ageInMonths = patient ? calculateAgeInMonths(patient.birthDate) : null;

    return (
        <ScrollView contentContainerStyle={styles.container}>
            <View style={styles.section}>
                <Text style={styles.sectionTitle}>Tahlil Tarihi ve Saati</Text>
                <DatePickerInput
                    label="Tarih"
                    date={date}
                    setDate={setDate}
                />
                <DateTimeInput
                    label="Saat"
                    dateTime={time}
                    setDateTime={setTime}
                    mode="time"
                />
            </View>

            <View style={styles.section}>
                <Text style={styles.sectionTitle}>Test Değerleri (g/L)</Text>
                {TEST_TYPES.map((testName) => (
                    <View key={testName} style={styles.testRow}>
                        <Icon name="flask" size={20} color="#333" style={styles.icon} />
                        <Text style={styles.testName}>{testName}:</Text>
                        <TextInput
                            placeholder={`Örn. ${testName} değeri (g/L)`}
                            value={testValues[testName] || ''}
                            onChangeText={(val) => setTestValues({ ...testValues, [testName]: val })}
                            keyboardType="numeric"
                            style={styles.input}
                        />
                    </View>
                ))}
            </View>

            <View style={styles.buttonContainer}>
                <Button
                    title={loading ? "Kaydediliyor..." : "Kaydet"}
                    onPress={saveTestResults}
                    disabled={loading}
                    color="#FF5722"
                />
                {loading && <ActivityIndicator size="large" color="#0000ff" style={styles.loader} />}
            </View>
        </ScrollView>
    );
};

export default AddTestResultScreen;

const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        padding: 20,
        backgroundColor: '#f5f5f5',
    },
    infoRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 10,
    },
    icon: {
        marginRight: 10,
        width: 25,
        textAlign: 'center',
    },
    label: {
        fontSize: 16,
        fontWeight: '600',
        flex: 1,
        color: '#333',
    },
    value: {
        fontSize: 16,
        color: '#555',
        flex: 2,
    },
    section: {
        backgroundColor: '#fff',
        padding: 15,
        borderRadius: 10,
        marginBottom: 20,
        elevation: 2,
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: '700',
        marginBottom: 15,
        color: '#333',
    },
    testRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 15,
    },
    testName: {
        fontSize: 16,
        fontWeight: '600',
        color: '#333',
        flex: 1,
    },
    input: {
        borderWidth: 1,
        borderColor: '#ccc',
        flex: 2,
        padding: 10,
        borderRadius: 5,
        backgroundColor: '#fafafa',
    },
    buttonContainer: {
        alignItems: 'center',
        marginBottom: 30,
    },
    loader: {
        marginTop: 10,
    },
});
