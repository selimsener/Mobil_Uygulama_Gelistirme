// ./screens/Doctor/EditAgeGroupScreen.js
import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    TextInput,
    Button,
    StyleSheet,
    Alert,
} from 'react-native';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { db } from '../../firebase';
import Ionicons from '@expo/vector-icons/Ionicons';

const EditAgeGroupScreen = ({ route, navigation }) => {
    const { guideId, testTypeName, ageGroup, index } = route.params;

    const [guideType, setGuideType] = useState(''); // "minMax" veya "geometric"
    const [ageRange, setAgeRange] = useState(ageGroup.ageRange);
    const [minValue, setMinValue] = useState(ageGroup.minValue?.toString() || '');
    const [maxValue, setMaxValue] = useState(ageGroup.maxValue?.toString() || '');
    const [geometricMean, setGeometricMean] = useState(ageGroup.geometricMean?.toString() || '');
    const [standardDeviation, setStandardDeviation] = useState(ageGroup.standardDeviation?.toString() || '');

    const fetchGuideType = async () => {
        try {
            const docRef = doc(db, 'guides', guideId);
            const docSnap = await getDoc(docRef);
            if (!docSnap.exists()) {
                Alert.alert('Hata', 'Klavuz bulunamadı');
                navigation.goBack();
                return;
            }
            const guide = docSnap.data();
            setGuideType(guide.type);
        } catch (error) {
            console.error('Klavuz tipi alınırken hata oluştu:', error);
            Alert.alert('Hata', 'Klavuz tipi alınamadı');
        }
    };

    useEffect(() => {
        fetchGuideType();
    }, []);

    const saveChanges = async () => {
        if (!ageRange) {
            Alert.alert('Hata', 'Yaş aralığı giriniz');
            return;
        }

        if (guideType === 'geometric' && (!geometricMean || !standardDeviation)) {
            Alert.alert('Hata', 'Geometric Mean ve Standard Deviation değerlerini doldurun');
            return;
        }

        if (guideType === 'minMax' && (!minValue || !maxValue)) {
            Alert.alert('Hata', 'Min ve Max değerlerini doldurun');
            return;
        }

        try {
            const docRef = doc(db, 'guides', guideId);
            const docSnap = await getDoc(docRef);
            if (!docSnap.exists()) {
                Alert.alert('Hata', 'Klavuz bulunamadı');
                navigation.goBack();
                return;
            }

            const guide = { id: docSnap.id, ...docSnap.data() };
            const testTypeIndex = guide.testTypes.findIndex((t) => t.name === testTypeName);
            if (testTypeIndex === -1) {
                Alert.alert('Hata', 'Test tipi bulunamadı');
                navigation.goBack();
                return;
            }

            let refMin, refMax;
            if (guideType === 'geometric') {
                const gm = parseFloat(geometricMean);
                const sd = parseFloat(standardDeviation);
                refMin = gm - sd;
                refMax = gm + sd;
            } else {
                refMin = parseFloat(minValue);
                refMax = parseFloat(maxValue);
            }

            const updatedAgeGroup = {
                ageRange,
                ...(guideType === 'geometric' && {
                    geometricMean: parseFloat(geometricMean),
                    standardDeviation: parseFloat(standardDeviation),
                }),
                ...(guideType === 'minMax' && {
                    minValue: parseFloat(minValue),
                    maxValue: parseFloat(maxValue),
                }),
                referenceMin: refMin,
                referenceMax: refMax,
            };

            const updatedTestType = { ...guide.testTypes[testTypeIndex] };
            updatedTestType.ageGroups[index] = updatedAgeGroup;

            const updatedTestTypes = [...guide.testTypes];
            updatedTestTypes[testTypeIndex] = updatedTestType;

            await updateDoc(doc(db, 'guides', guide.id), { testTypes: updatedTestTypes });
            Alert.alert('Başarılı', 'Yaş grubu başarıyla güncellendi');
            navigation.goBack();
        } catch (error) {
            console.error('Güncelleme hatası:', error);
            Alert.alert('Hata', 'Yaş grubu güncellenemedi');
        }
    };

    return (
        <View style={styles.container}>
            <View style={styles.headerRow}>
                <Ionicons name="people-outline" size={24} color="#333" style={styles.icon} />
                <Text style={styles.title}>Yaş Grubunu Düzenle</Text>
            </View>

            <Text style={styles.label}>Yaş Aralığı</Text>
            <TextInput
                placeholder="Örn: 0-1 veya 121+"
                value={ageRange}
                onChangeText={setAgeRange}
                style={styles.input}
            />

            {guideType === 'minMax' && (
                <>
                    <Text style={styles.label}>Min Değer</Text>
                    <TextInput
                        placeholder="Min Değer"
                        value={minValue}
                        onChangeText={setMinValue}
                        style={styles.input}
                        keyboardType="numeric"
                    />
                    <Text style={styles.label}>Max Değer</Text>
                    <TextInput
                        placeholder="Max Değer"
                        value={maxValue}
                        onChangeText={setMaxValue}
                        style={styles.input}
                        keyboardType="numeric"
                    />
                </>
            )}

            {guideType === 'geometric' && (
                <>
                    <Text style={styles.label}>Geometric Mean</Text>
                    <TextInput
                        placeholder="Geometric Ortalama"
                        value={geometricMean}
                        onChangeText={setGeometricMean}
                        style={styles.input}
                        keyboardType="numeric"
                    />
                    <Text style={styles.label}>Standard Deviation</Text>
                    <TextInput
                        placeholder="Standard Sapma"
                        value={standardDeviation}
                        onChangeText={setStandardDeviation}
                        style={styles.input}
                        keyboardType="numeric"
                    />
                </>
            )}

            <Button title="Kaydet" onPress={saveChanges} />
        </View>
    );
};

export default EditAgeGroupScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        backgroundColor: '#f5f5f5',
    },
    headerRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 15,
    },
    icon: {
        marginRight: 8,
    },
    title: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#333',
    },
    label: {
        fontSize: 14,
        fontWeight: '600',
        marginBottom: 5,
        color: '#333',
    },
    input: {
        borderWidth: 1,
        borderColor: '#ccc',
        marginBottom: 15,
        padding: 10,
        backgroundColor: '#fff',
        borderRadius: 6,
    },
});
