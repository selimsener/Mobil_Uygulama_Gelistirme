// screens/Doctor/PatientUpdateScreen.js
import React, { useState, useEffect } from 'react';
import { View, Text, Alert, StyleSheet, TouchableOpacity, ScrollView, ActivityIndicator } from 'react-native';
import CustomInput from '../../components/CustomInput';
import CustomButton from '../../components/CustomButton';
import DatePickerInput from '../../components/DatePickerInput';
import { db } from '../../firebase';
import { doc, getDoc, setDoc, collection, query, where, getDocs } from 'firebase/firestore';
import { updateEmail } from 'firebase/auth';
import { validateEmail, validatePassword, validateName, validateTC, validateDate } from '../../utils/validators';

const PatientUpdateScreen = ({ route, navigation }) => {
    const { patientId } = route.params;
    const [email, setEmail] = useState("");
    const [tc, setTc] = useState("");
    const [name, setName] = useState("");
    const [birthDate, setBirthDate] = useState(new Date());
    const [loading, setLoading] = useState(false);
    const [initialData, setInitialData] = useState(null);

    useEffect(() => {
        const fetchPatient = async () => {
            setLoading(true);
            try {
                const patientDoc = await getDoc(doc(db, 'users', patientId));
                if (patientDoc.exists()) {
                    const data = patientDoc.data();
                    setName(data.name);
                    setEmail(data.email);
                    setTc(data.tc);
                    setBirthDate(new Date(data.birthDate));
                    setInitialData(data);
                } else {
                    Alert.alert("Hata", "Hasta bulunamadı.");
                    navigation.goBack();
                }
            } catch (error) {
                console.error("Hasta alınırken hata:", error);
                Alert.alert("Hata", "Hasta bilgileri alınırken bir sorun oluştu.");
                navigation.goBack();
            } finally {
                setLoading(false);
            }
        };
        fetchPatient();
    }, [patientId]);

    const handleUpdatePatient = async () => {
        // Input validation
        if (!validateEmail(email)) {
            Alert.alert("Hata", "Geçerli bir email giriniz.");
            return;
        }
        if (!validateName(name)) {
            Alert.alert("Hata", "İsim soyisim alanı boş olamaz.");
            return;
        }
        if (!validateTC(tc)) {
            Alert.alert("Hata", "TC kimlik numarası 11 haneli olmalı.");
            return;
        }
        if (!validateDate(birthDate)) {
            Alert.alert("Hata", "Lütfen geçerli bir doğum tarihi seçiniz.");
            return;
        }

        setLoading(true);

        try {
            const usersRef = collection(db, 'users');

            // Email benzersizliğini kontrol et
            if (email !== initialData.email) {
                const emailQuery = query(usersRef, where('email', '==', email));
                const emailSnap = await getDocs(emailQuery);
                if (!emailSnap.empty) {
                    Alert.alert("Hata", "Bu email zaten kullanılıyor.");
                    setLoading(false);
                    return;
                }
            }

            // TC benzersizliğini kontrol et
            if (tc !== initialData.tc) {
                const tcQuery = query(usersRef, where('tc', '==', tc));
                const tcSnap = await getDocs(tcQuery);
                if (!tcSnap.empty) {
                    Alert.alert("Hata", "Bu TC kimlik numarası zaten kullanılıyor.");
                    setLoading(false);
                    return;
                }
            }

            // Kullanıcı verilerini güncelle
            const formattedBirthDate = birthDate.toISOString().split('T')[0]; // YYYY-MM-DD

            await setDoc(doc(db, 'users', patientId), {
                name,
                email,
                tc,
                birthDate: formattedBirthDate,
                searchName: name.toLowerCase(),
                updatedAt: new Date(),
            }, { merge: true });

            // Email değiştiyse Firebase Auth'ta güncelle
            if (email !== initialData.email) {
                // Firebase Auth'ta başka bir kullanıcının emailini güncellemek için admin yetkisi gereklidir.
                // Bu işlem client tarafında yapılamaz. Bu nedenle, aşağıdaki kod mevcut kullanıcı için örnek olarak verilmiştir.
                // Başka kullanıcıların emailini güncellemek için Firebase Admin SDK kullanmalısınız.
                Alert.alert("Bilgi", "Email güncellemesi için lütfen yöneticiye başvurun.");
            }

            Alert.alert("Başarılı", "Hasta başarıyla güncellendi.");
            navigation.goBack();
        } catch (error) {
            console.error("Hasta güncelleme hatası:", error);
            Alert.alert("Hata", "Hasta güncellenirken bir sorun oluştu. Lütfen tekrar deneyin.");
        } finally {
            setLoading(false);
        }
    };

    if (loading && !initialData) {
        return (
            <View style={styles.loaderContainer}>
                <ActivityIndicator size="large" color="#007BFF" />
            </View>
        );
    }

    return (
        <ScrollView contentContainerStyle={styles.container}>
            <Text style={styles.title}>Hasta Güncelle</Text>
            <CustomInput
                label="Ad Soyad"
                placeholder="Ad Soyad"
                value={name}
                onChangeText={setName}
            />
            <DatePickerInput
                label="Doğum Tarihi"
                date={birthDate}
                setDate={setBirthDate}
            />
            <CustomInput
                label="TC"
                placeholder="TC Kimlik Numarası"
                value={tc}
                onChangeText={setTc}
                keyboardType="numeric"
            />
            <CustomInput
                label="Email"
                placeholder="Email"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
            />
            <CustomButton title={loading ? "Güncelleniyor..." : "Güncelle"} onPress={handleUpdatePatient} disabled={loading} />
            <TouchableOpacity onPress={() => navigation.goBack()}>
                <Text style={styles.link}>
                    Geri dön <Text style={styles.linkHighlight}>Hasta Yönetimi</Text>
                </Text>
            </TouchableOpacity>
        </ScrollView>
    );
};

export default PatientUpdateScreen;

const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        padding: 20,
        justifyContent: 'center',
        backgroundColor: '#fff',
    },
    loaderContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 20,
        textAlign: 'center',
    },
    link: {
        textAlign: 'center',
        marginTop: 15,
        fontSize: 14,
    },
    linkHighlight: {
        color: "#007BFF",
        fontWeight: "bold",
    },
});
