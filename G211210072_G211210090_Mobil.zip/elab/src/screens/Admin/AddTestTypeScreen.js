// ./screens/Doctor/AddTestTypeScreen.js
import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    Alert,
    StyleSheet,
    Button,
    FlatList,
    TouchableOpacity,
} from 'react-native';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { db } from '../../firebase';
import { TEST_TYPES } from '../../constants/testTypes';

const AddTestTypeScreen = ({ route, navigation }) => {
    const { guideId } = route.params;
    const [guide, setGuide] = useState(null);
    const [availableTestTypes, setAvailableTestTypes] = useState([]);
    const [selectedTestTypes, setSelectedTestTypes] = useState([]);

    // Firestore'dan klavuz bilgilerini çek
    const fetchGuide = async () => {
        try {
            const guideRef = doc(db, 'guides', guideId);
            const snap = await getDoc(guideRef);

            if (!snap.exists()) {
                Alert.alert('Hata', 'Klavuz bulunamadı');
                navigation.goBack();
                return;
            }

            const g = snap.data();
            setGuide(g);

            const existingTestTypes = g.testTypes.map(t => t.name);
            const remainingTestTypes = TEST_TYPES.filter(tt => !existingTestTypes.includes(tt));
            setAvailableTestTypes(remainingTestTypes);
        } catch (error) {
            console.error('Veri çekme hatası:', error);
            Alert.alert('Hata', 'Test tipleri yüklenemedi');
        }
    };

    useEffect(() => {
        fetchGuide();
    }, []);

    // Seçim işlemi
    const toggleTestTypeSelection = (testType) => {
        if (selectedTestTypes.includes(testType)) {
            setSelectedTestTypes(selectedTestTypes.filter(tt => tt !== testType));
        } else {
            setSelectedTestTypes([...selectedTestTypes, testType]);
        }
    };

    // Seçilen test tiplerini Firestore'a ekle
    const addTestTypes = async () => {
        if (selectedTestTypes.length === 0) {
            Alert.alert('Hata', 'Lütfen en az bir test tipi seçin');
            return;
        }

        try {
            const guideRef = doc(db, 'guides', guideId);
            const newTestTypes = selectedTestTypes.map(name => ({
                name,
                ageGroups: [],
            }));

            await updateDoc(guideRef, {
                testTypes: [...guide.testTypes, ...newTestTypes],
            });

            Alert.alert('Başarılı', 'Test tipleri eklendi');
            navigation.goBack();
        } catch (error) {
            console.error('Güncelleme hatası:', error);
            Alert.alert('Hata', 'Test tipleri eklenemedi');
        }
    };

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Test Tipi Ekle</Text>

            {/* Seçilen test tipleri */}
            {selectedTestTypes.length > 0 && (
                <View style={styles.selectedContainer}>
                    <Text style={styles.selectedTitle}>Seçilen Test Tipleri:</Text>
                    {selectedTestTypes.map((type, index) => (
                        <Text key={index} style={styles.selectedItem}>{type}</Text>
                    ))}
                </View>
            )}

            {/* Mevcut (eklenmemiş) test tipleri listesi */}
            <FlatList
                data={availableTestTypes}
                keyExtractor={(item) => item}
                renderItem={({ item }) => (
                    <TouchableOpacity
                        style={[
                            styles.testTypeItem,
                            selectedTestTypes.includes(item) && styles.selectedTestTypeItem,
                        ]}
                        onPress={() => toggleTestTypeSelection(item)}
                    >
                        <Text
                            style={[
                                styles.testTypeText,
                                selectedTestTypes.includes(item) && styles.testTypeTextSelected,
                            ]}
                        >
                            {item}
                        </Text>
                    </TouchableOpacity>
                )}
                ListEmptyComponent={<Text style={styles.emptyText}>Tüm test tipleri eklendi.</Text>}
            />

            {/* Ekle butonu */}
            {availableTestTypes.length > 0 && (
                <Button
                    title="Ekle"
                    onPress={addTestTypes}
                    disabled={selectedTestTypes.length === 0}
                />
            )}
        </View>
    );
};

export default AddTestTypeScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        backgroundColor: '#f5f5f5',
    },
    title: {
        fontSize: 18,
        fontWeight: 'bold',
        marginBottom: 10,
        color: '#333',
    },
    selectedContainer: {
        marginBottom: 20,
        padding: 10,
        backgroundColor: '#e0f7fa',
        borderRadius: 5,
    },
    selectedTitle: {
        fontWeight: 'bold',
        marginBottom: 5,
        color: '#007BFF',
    },
    selectedItem: {
        fontSize: 14,
        color: '#007BFF',
        marginLeft: 10,
    },
    testTypeItem: {
        padding: 15,
        marginVertical: 5,
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#ccc',
        backgroundColor: '#f5f5f5',
    },
    selectedTestTypeItem: {
        backgroundColor: '#007BFF',
        borderColor: '#0056b3',
    },
    testTypeText: {
        fontSize: 16,
        color: '#333',
        textAlign: 'center',
    },
    testTypeTextSelected: {
        color: '#fff',
    },
    emptyText: {
        textAlign: 'center',
        color: '#888',
        fontSize: 16,
        marginTop: 20,
    },
});
