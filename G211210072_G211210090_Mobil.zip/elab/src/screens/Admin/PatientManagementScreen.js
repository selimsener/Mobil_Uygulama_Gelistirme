// screens/Doctor/PatientManagementScreen.js
import React, { useEffect, useState, useRef } from 'react';
import {
    View,
    Text,
    TextInput,
    FlatList,
    TouchableOpacity,
    StyleSheet,
    Alert,
    ActivityIndicator,
} from 'react-native';
import { collection, query, where, getDocs, deleteDoc, doc } from 'firebase/firestore';
import { db } from '../../firebase';
import { useFocusEffect } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/Ionicons';
import { calculateAgeInMonths } from '../../utils/ageCalculator';

const PatientManagementScreen = ({ navigation }) => {
    const [searchValue, setSearchValue] = useState('');
    const [allPatients, setAllPatients] = useState([]);
    const [filteredPatients, setFilteredPatients] = useState([]);
    const [loading, setLoading] = useState(false);
    const debounceTimeout = useRef(null);

    const fetchPatients = async () => {
        setLoading(true);
        try {
            const patientsSnap = await getDocs(
                query(collection(db, 'users'), where('role', '==', 'patient'))
            );
            const patientsList = [];
            patientsSnap.forEach((docSnap) => {
                const data = docSnap.data();
                // Arama kolaylığı için küçük harfe çeviriyoruz
                const searchName = data.searchName
                    ? data.searchName.toLowerCase()
                    : data.name
                        ? data.name.toLowerCase()
                        : '';

                // Doğum tarihi formatlanmış
                const formattedBirthDate = data.birthDate
                    ? new Date(data.birthDate).toLocaleDateString()
                    : '';

                // Ay olarak yaş
                const ageInMonths = data.birthDate
                    ? calculateAgeInMonths(data.birthDate)
                    : null;

                patientsList.push({
                    id: docSnap.id,
                    ...data,
                    searchName,
                    formattedBirthDate,
                    ageInMonths, // Ay cinsinden yaş
                });
            });
            setAllPatients(patientsList);
            setFilteredPatients(patientsList);
        } catch (error) {
            console.error('Hastalar alınırken hata:', error);
            Alert.alert('Hata', 'Hastalar yüklenirken bir hata oluştu.');
        } finally {
            setLoading(false);
        }
    };

    const filterPatients = () => {
        if (searchValue.trim() === '') {
            setFilteredPatients(allPatients);
            return;
        }

        const trimmedValue = searchValue.trim().toLowerCase();
        let results = [];

        if (/^\d+$/.test(trimmedValue)) {
            // TC partial search
            results = allPatients.filter(patient =>
                (patient.tc || '').includes(trimmedValue)
            );
        } else if (!isNaN(Date.parse(trimmedValue))) {
            // Doğum tarihi partial search
            results = allPatients.filter(patient =>
                (patient.formattedBirthDate || '').includes(trimmedValue)
            );
        } else {
            // İsim partial search
            results = allPatients.filter(patient =>
                (patient.searchName || '').includes(trimmedValue)
            );
        }
        setFilteredPatients(results);
    };

    const searchPatients = () => {
        filterPatients();
    };

    const handleDelete = (patient) => {
        Alert.alert(
            "Onayla",
            `${patient.name} adlı hastayı silmek istediğinize emin misiniz?`,
            [
                {
                    text: "İptal",
                    style: "cancel"
                },
                {
                    text: "Sil",
                    style: "destructive",
                    onPress: () => deletePatient(patient)
                }
            ]
        );
    };

    const deletePatient = async (patient) => {
        setLoading(true);
        try {
            await deleteDoc(doc(db, 'users', patient.id));
            Alert.alert("Başarılı", "Hasta başarıyla silindi.");
            fetchPatients();
        } catch (error) {
            console.error("Hasta silme hatası:", error);
            Alert.alert("Hata", "Hasta silinirken bir sorun oluştu. Lütfen tekrar deneyin.");
        } finally {
            setLoading(false);
        }
    };

    useFocusEffect(
        React.useCallback(() => {
            fetchPatients();
        }, [])
    );

    useEffect(() => {
        if (debounceTimeout.current) {
            clearTimeout(debounceTimeout.current);
        }
        debounceTimeout.current = setTimeout(() => {
            filterPatients();
        }, 500);

        return () => {
            if (debounceTimeout.current) {
                clearTimeout(debounceTimeout.current);
            }
        };
    }, [searchValue, allPatients]);

    return (
        <View style={styles.container}>

            {/* Arama Alanı */}
            <View style={styles.searchContainer}>
                <TextInput
                    placeholder="TC veya isim ile arama"
                    style={styles.input}
                    value={searchValue}
                    onChangeText={setSearchValue}
                />
                <TouchableOpacity style={styles.searchButton} onPress={searchPatients}>
                    <Icon name="search" size={18} color="#fff" style={{ marginRight: 5 }} />
                    <Text style={styles.searchButtonText}>Ara</Text>
                </TouchableOpacity>
            </View>

            {/* Hasta Ekle Butonu */}
            <TouchableOpacity
                style={styles.addButton}
                onPress={() => navigation.navigate('PatientAdd')}
            >
                <Text style={styles.addButtonText}>Hasta Ekle</Text>
            </TouchableOpacity>

            {loading ? (
                <ActivityIndicator size="large" color="#007BFF" style={styles.loader} />
            ) : (
                <FlatList
                    data={filteredPatients}
                    keyExtractor={(item) => item.id}
                    ListEmptyComponent={<Text style={styles.empty}>Hasta bulunamadı</Text>}
                    renderItem={({ item }) => (
                        // Tüm kart "TouchableOpacity" oldu:
                        <TouchableOpacity
                            style={styles.patientCard}
                            onPress={() => navigation.navigate('PatientDetail', { patientId: item.id })}
                        >
                            <View style={styles.patientInfo}>
                                <View style={styles.patientNameRow}>
                                    <Icon name="person" size={20} color="#333" style={styles.icon} />
                                    <Text style={styles.patientName}>{item.name}</Text>
                                </View>
                                <View style={styles.infoRow}>
                                    <Icon name="document-text" size={18} color="#333" style={styles.icon} />
                                    <Text style={styles.patientDetails}>TC: {item.tc}</Text>
                                </View>
                                <View style={styles.infoRow}>
                                    <Icon name="calendar" size={18} color="#333" style={styles.icon} />
                                    <Text style={styles.patientDetails}>
                                        Doğum Tarihi: {item.formattedBirthDate || 'Belirsiz'}
                                    </Text>
                                </View>
                                {item.ageInMonths !== null && (
                                    <View style={styles.infoRow}>
                                        <Icon name="time" size={18} color="#333" style={styles.icon} />
                                        <Text style={styles.patientDetails}>
                                            Yaş (ay): {item.ageInMonths}
                                        </Text>
                                    </View>
                                )}
                            </View>

                            <View style={styles.actionButtons}>
                                <TouchableOpacity
                                    style={styles.updateButton}
                                    onPress={() => {
                                        navigation.navigate('PatientUpdate', { patientId: item.id });
                                    }}
                                >
                                    <Icon name="pencil" size={16} color="#fff" style={styles.buttonIcon} />
                                    <Text style={styles.buttonText}>Güncelle</Text>
                                </TouchableOpacity>

                                <TouchableOpacity
                                    style={styles.deleteButton}
                                    onPress={() => {
                                        // Kartın tıklanmasını engellemek için
                                        // buraya onPress koyuyoruz.
                                        handleDelete(item);
                                    }}
                                >
                                    <Icon name="trash" size={16} color="#fff" style={styles.buttonIcon} />
                                    <Text style={styles.buttonText}>Sil</Text>
                                </TouchableOpacity>
                            </View>
                        </TouchableOpacity>
                    )}
                />
            )}
        </View>
    );
};

export default PatientManagementScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        backgroundColor: '#f9f9f9',
    },
    searchContainer: {
        flexDirection: 'row',
        marginBottom: 10,
    },
    input: {
        flex: 1,
        borderWidth: 1,
        borderColor: '#ccc',
        padding: 10,
        marginRight: 10,
        borderRadius: 5,
        backgroundColor: '#fff',
    },
    searchButton: {
        flexDirection: 'row',
        backgroundColor: '#007BFF',
        borderRadius: 5,
        paddingVertical: 10,
        paddingHorizontal: 15,
        alignItems: 'center',
        justifyContent: 'center',
    },
    searchButtonText: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 15,
    },
    addButton: {
        backgroundColor: '#28a745',
        paddingVertical: 12,
        borderRadius: 5,
        marginBottom: 15,
    },
    addButtonText: {
        color: '#fff',
        textAlign: 'center',
        fontWeight: 'bold',
        fontSize: 16,
    },
    loader: {
        marginTop: 20,
    },
    empty: {
        textAlign: 'center',
        color: '#888',
        marginTop: 20,
    },
    // Hasta kartı
    patientCard: {
        backgroundColor: '#fff',
        borderRadius: 8,
        padding: 15,
        marginBottom: 15,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        elevation: 2,
    },
    patientInfo: {
        flex: 1,
        marginRight: 10,
    },
    patientNameRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 6,
    },
    patientName: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#333',
        marginLeft: 5,
    },
    infoRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 4,
    },
    icon: {
        marginRight: 6,
    },
    patientDetails: {
        fontSize: 14,
        color: '#555',
    },
    actionButtons: {
        justifyContent: 'space-between',
    },
    updateButton: {
        flexDirection: 'row',
        backgroundColor: '#ffc107',
        paddingVertical: 6,
        paddingHorizontal: 12,
        borderRadius: 5,
        marginBottom: 8,
        alignItems: 'center',
    },
    deleteButton: {
        flexDirection: 'row',
        backgroundColor: '#dc3545',
        paddingVertical: 6,
        paddingHorizontal: 12,
        borderRadius: 5,
        alignItems: 'center',
    },
    buttonIcon: {
        marginRight: 5,
    },
    buttonText: {
        color: '#fff',
        fontWeight: 'bold',
    },
});
