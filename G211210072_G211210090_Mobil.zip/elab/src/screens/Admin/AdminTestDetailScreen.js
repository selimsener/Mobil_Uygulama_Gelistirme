// src/screens/Admin/AdminTestDetailScreen.js

import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ActivityIndicator,
    ScrollView,
    Dimensions,
    Alert,
} from 'react-native';
import { doc, getDoc, collection, query as firestoreQuery, orderBy, getDocs } from 'firebase/firestore';
import { db } from '../../firebase';
import { VictoryChart, VictoryLine, VictoryScatter, VictoryAxis } from 'victory-native';
import Icon from 'react-native-vector-icons/Ionicons'; // Doğru import edildiğinden emin olun

// Yardımcı Fonksiyonlar
const getStatusColor = (status) => {
    switch (status) {
        case 'Yüksek':
            return 'red';
        case 'Normal':
            return 'green';
        case 'Düşük':
            return 'orange';
        default:
            return 'grey';
    }
};

const getStatusIcon = (status) => {
    switch (status) {
        case 'Yüksek':
            return 'arrow-up-circle';
        case 'Normal':
            return 'checkmark-circle';
        case 'Düşük':
            return 'arrow-down-circle';
        default:
            return 'help-circle';
    }
};

const determineDominantStatus = (evaluations) => {
    if (!evaluations || evaluations.length === 0) return 'Unknown';
    const statusCounts = evaluations.reduce((acc, evalItem) => {
        acc[evalItem.status] = (acc[evalItem.status] || 0) + 1;
        return acc;
    }, {});

    const dominantStatus = Object.keys(statusCounts).reduce((a, b) =>
            statusCounts[a] > statusCounts[b] ? a : b
        , '');

    return dominantStatus || 'Unknown';
};

const formatNumber = (num) => {
    return Number(num).toFixed(2).replace('.', ',');
};

// Grafik Bileşeni
const TestTrendChart = ({ testName, patientId }) => {
    const [chartData, setChartData] = useState(null);

    useEffect(() => {
        loadChartData();
    }, [testName]);

    const loadChartData = async () => {
        const data = await prepareChartData(testName);
        setChartData(data);
    };

    const prepareChartData = async (testName) => {
        try {
            const resultsQuery = firestoreQuery(
                collection(db, 'users', patientId, 'results'),
                orderBy('date', 'asc')
            );
            const querySnapshot = await getDocs(resultsQuery);
            const dataPoints = [];
            const labels = [];

            querySnapshot.forEach(doc => {
                const dataObj = doc.data();
                const date = dataObj.date.toDate().toLocaleDateString();
                const test = dataObj.tests ? dataObj.tests.find(t => t.name === testName) : null;
                if (test) {
                    const dominantStatus = determineDominantStatus(test.evaluations);
                    labels.push(date);
                    dataPoints.push({
                        x: date,
                        y: Number(test.value.toFixed(2)),
                        status: dominantStatus,
                    });
                }
            });

            return {
                dataPoints,
                labels
            };
        } catch (error) {
            console.error("Grafik verisi alınamadı: ", error);
            Alert.alert('Hata', 'Grafik verisi alınırken bir hata oluştu.');
            return {
                dataPoints: [],
                labels: []
            };
        }
    };

    if (!chartData || chartData.dataPoints.length === 0) {
        return <Text style={styles.noDataText}>Grafik için yeterli veri bulunmamaktadır.</Text>;
    }

    const chartWidth = Math.max(chartData.dataPoints.length * 50, Dimensions.get('window').width);

    // Y eksenindeki değerleri formatlama
    const formatYAxis = (y) => {
        if (y >= 1000) {
            return `${y / 1000}k`;
        }
        return y.toFixed(2);
    };

    return (
        <ScrollView horizontal>
            <VictoryChart
                width={chartWidth}
                height={220}
                domainPadding={{ x: 50, y: 20 }}
                padding={{ top: 20, bottom: 50, left: 50, right: 50 }}
            >
                <VictoryAxis
                    tickValues={chartData.labels}
                    tickFormat={(t) => t}
                    style={{
                        tickLabels: { angle: -45, fontSize: 10, padding: 15 },
                    }}
                />
                <VictoryAxis
                    dependentAxis
                    tickFormat={(x) => formatYAxis(x)}
                    style={{
                        tickLabels: { fontSize: 10, padding: 5 },
                    }}
                />
                <VictoryLine
                    data={chartData.dataPoints}
                    x="x"
                    y="y"
                    style={{
                        data: { stroke: "#1e90ff" },
                    }}
                />
                <VictoryScatter
                    data={chartData.dataPoints}
                    x="x"
                    y="y"
                    size={5}
                    style={{
                        data: {
                            fill: ({ datum }) => getStatusColor(datum.status),
                        }
                    }}
                />
            </VictoryChart>
        </ScrollView>
    );
};

// Admin Test Detail Screen
const AdminTestDetailScreen = ({ route, navigation }) => {
    const { patientId, testId } = route.params;
    const [testDetail, setTestDetail] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchTestDetail();
    }, []);

    const fetchTestDetail = async () => {
        setLoading(true);
        try {
            const docRef = doc(db, 'users', patientId, 'results', testId);
            const docSnap = await getDoc(docRef);
            if (docSnap.exists()) {
                setTestDetail(docSnap.data());
            } else {
                Alert.alert('Hata', 'Belge bulunamadı!');
            }
        } catch (error) {
            Alert.alert('Hata', 'Veri alınamadı: ' + error.message);
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return <ActivityIndicator size="large" color="#0000ff" style={styles.loader} />;
    }

    if (!testDetail) {
        return (
            <View style={styles.container}>
                <Text>Veri bulunamadı.</Text>
            </View>
        );
    }

    return (
        <ScrollView style={styles.container}>
            <Text style={styles.date}>{testDetail.date.toDate().toLocaleString()}</Text>
            {testDetail.tests && testDetail.tests.length > 0 ? (
                testDetail.tests.map((test, index) => (
                    <View key={index} style={styles.testContainer}>
                        <View style={styles.testHeader}>
                            <Icon
                                name="flask"
                                size={18}
                                color="#333"
                                style={{ marginRight: 5 }}
                            />
                            <Text style={styles.testName}>{test.name}: {test.value}</Text>
                        </View>
                        {test.evaluations && test.evaluations.length > 0 ? (
                            test.evaluations.map((evalItem, evalIndex) => (
                                <View
                                    key={evalIndex}
                                    style={styles.evaluationContainer}
                                >
                                    <Text style={styles.guideName}>{evalItem.guideName}:</Text>
                                    <Text style={styles.evalText}>
                                        Klavuz birimi: {evalItem.unit || 'Belirtilmemiş'}
                                    </Text>
                                    <Text style={styles.reference}>
                                        Referans Aralığı: {formatNumber(evalItem.referenceMin)} - {formatNumber(evalItem.referenceMax)}
                                    </Text>
                                    {/* Durum + İkon */}
                                    <View style={styles.statusRow}>
                                        <Icon
                                            name={getStatusIcon(evalItem.status)}
                                            size={16}
                                            color={getStatusColor(evalItem.status)}
                                            style={styles.statusIcon}
                                        />
                                        <Text
                                            style={[
                                                styles.statusValue,
                                                {
                                                    color: getStatusColor(evalItem.status),
                                                },
                                            ]}
                                        >
                                            {evalItem.status}
                                        </Text>
                                    </View>
                                </View>
                            ))
                        ) : (
                            <Text style={styles.noEvaluations}>Değerlendirme bulunmamaktadır.</Text>
                        )}

                        {/* Grafik Bileşeni */}
                        <TestTrendChart
                            testName={test.name}
                            patientId={patientId}
                        />
                    </View>
                ))
            ) : (
                <Text style={styles.noTestsText}>Bu test için detaylı bilgi bulunmamaktadır.</Text>
            )}
        </ScrollView>
    );
};

export default AdminTestDetailScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 10,
        backgroundColor: '#f5f5f5',
    },
    loader: {
        flex: 1,
        justifyContent: 'center',
    },
    date: {
        fontSize: 18,
        fontWeight: 'bold',
        marginBottom: 15,
        textAlign: 'center',
    },
    testContainer: {
        backgroundColor: '#fff',
        padding: 15,
        marginBottom: 20,
        borderRadius: 10,
        elevation: 2,
    },
    testHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 10,
    },
    testName: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#333',
    },
    evaluationContainer: {
        marginTop: 5,
        padding: 10,
        borderWidth: 1,
        borderColor: '#ddd',
        borderRadius: 5,
        backgroundColor: '#e9ecef',
    },
    guideName: {
        fontWeight: 'bold',
        fontSize: 14,
    },
    evalText: {
        fontSize: 14,
    },
    reference: {
        fontSize: 14,
        color: '#000',
        marginTop: 5,
    },
    statusRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 3,
    },
    statusIcon: {
        marginRight: 4,
    },
    statusValue: {
        fontSize: 14,
        fontWeight: 'bold',
    },
    noEvaluations: {
        fontSize: 14,
        color: '#888',
        marginTop: 5,
    },
    noTestsText: {
        textAlign: 'center',
        color: '#888',
        marginTop: 20,
    },
    noDataText: {
        textAlign: 'center',
        color: '#888',
        marginTop: 10,
    },
});
