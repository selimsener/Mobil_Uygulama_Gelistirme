// ./screens/Doctor/AddAgeGroupScreen.js
import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    TextInput,
    Button,
    StyleSheet,
    Alert,
    TouchableOpacity,
} from 'react-native';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { db } from '../../firebase';
import Ionicons from '@expo/vector-icons/Ionicons';

const AddAgeGroupScreen = ({ route, navigation }) => {
    const { guideId, testTypeName } = route.params;
    const [ageRange, setAgeRange] = useState('');
    const [minValue, setMinValue] = useState('');
    const [maxValue, setMaxValue] = useState('');
    const [geometricMean, setGeometricMean] = useState('');
    const [standardDeviation, setStandardDeviation] = useState('');
    const [guide, setGuide] = useState(null);
    const [testType, setTestType] = useState(null);

    const fetchData = async () => {
        try {
            const docRef = doc(db, 'guides', guideId);
            const docSnap = await getDoc(docRef);

            if (docSnap.exists()) {
                const g = { id: docSnap.id, ...docSnap.data() };
                setGuide(g);

                const tt = g.testTypes.find((t) => t.name === testTypeName);
                if (!tt) {
                    Alert.alert('Hata', 'Test tipi bulunamadı');
                    navigation.goBack();
                    return;
                }
                setTestType(tt);
            } else {
                Alert.alert('Hata', 'Klavuz bulunamadı');
                navigation.goBack();
            }
        } catch (error) {
            console.error('Veri çekme hatası:', error);
            Alert.alert('Hata', 'Veri yüklenirken bir hata oluştu');
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    const addAgeGroup = async () => {
        if (!ageRange) {
            Alert.alert('Hata', 'Yaş aralığı giriniz');
            return;
        }

        if (!guide || !testType) return;

        let refMin, refMax;
        if (guide.type === 'geometric') {
            if (!geometricMean || !standardDeviation) {
                Alert.alert('Hata', 'Geometric Mean ve Standart Sapma değerleri giriniz');
                return;
            }
            const gm = parseFloat(geometricMean);
            const sd = parseFloat(standardDeviation);
            refMin = gm - sd;
            refMax = gm + sd;
        } else if (guide.type === 'minMax') {
            if (!minValue || !maxValue) {
                Alert.alert('Hata', 'Min ve Max değerleri giriniz');
                return;
            }
            refMin = parseFloat(minValue);
            refMax = parseFloat(maxValue);
        }

        const newAgeGroup = {
            ageRange,
            ...(guide.type === 'geometric' && {
                geometricMean: parseFloat(geometricMean),
                standardDeviation: parseFloat(standardDeviation),
            }),
            ...(guide.type === 'minMax' && {
                minValue: parseFloat(minValue),
                maxValue: parseFloat(maxValue),
            }),
            referenceMin: refMin,
            referenceMax: refMax,
        };

        try {
            const docRef = doc(db, 'guides', guide.id);
            const updatedTestTypes = guide.testTypes.map((tt) => {
                if (tt.name === testTypeName) {
                    return {
                        ...tt,
                        ageGroups: [...tt.ageGroups, newAgeGroup],
                    };
                }
                return tt;
            });

            await updateDoc(docRef, { testTypes: updatedTestTypes });
            Alert.alert('Başarılı', 'Yaş grubu eklendi');
            navigation.goBack();
        } catch (error) {
            console.error('Güncelleme hatası:', error);
            Alert.alert('Hata', 'Yaş grubu eklenemedi');
        }
    };

    return (
        <View style={styles.container}>
            <View style={styles.headerRow}>
                <Ionicons name="person-outline" size={24} color="#333" style={styles.icon} />
                <Text style={styles.title}>Yaş Grubu Ekle</Text>
            </View>

            <TextInput
                placeholder="Yaş Aralığı (örnek: 0-1 veya 121+)"
                value={ageRange}
                onChangeText={setAgeRange}
                style={styles.input}
            />
            {guide?.type === 'minMax' && (
                <>
                    <TextInput
                        placeholder="Min Değer"
                        value={minValue}
                        onChangeText={setMinValue}
                        style={styles.input}
                        keyboardType="numeric"
                    />
                    <TextInput
                        placeholder="Max Değer"
                        value={maxValue}
                        onChangeText={setMaxValue}
                        style={styles.input}
                        keyboardType="numeric"
                    />
                </>
            )}
            {guide?.type === 'geometric' && (
                <>
                    <TextInput
                        placeholder="Geometric Mean"
                        value={geometricMean}
                        onChangeText={setGeometricMean}
                        style={styles.input}
                        keyboardType="numeric"
                    />
                    <TextInput
                        placeholder="Standard Deviation"
                        value={standardDeviation}
                        onChangeText={setStandardDeviation}
                        style={styles.input}
                        keyboardType="numeric"
                    />
                </>
            )}
            <Button title="Kaydet" onPress={addAgeGroup} />
        </View>
    );
};

export default AddAgeGroupScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        backgroundColor: '#f5f5f5',
    },
    headerRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 15,
    },
    icon: {
        marginRight: 8,
    },
    title: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#333',
    },
    input: {
        borderWidth: 1,
        borderColor: '#ccc',
        marginBottom: 10,
        padding: 10,
        backgroundColor: '#fff',
        borderRadius: 6,
    },
});
