// screens/EditTestResultScreen.js
import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    TextInput,
    StyleSheet,
    Alert,
    ScrollView,
    ActivityIndicator,
    TouchableOpacity,
} from 'react-native';
import { doc, getDoc, updateDoc, collection, getDocs } from 'firebase/firestore';
import { db } from '../../firebase';
import { calculateAgeInMonths } from '../../utils/ageCalculator';
import { isAgeInRange } from '../../utils/ageRangeEvaluator';
import { TEST_TYPES } from '../../constants/testTypes';
import Icon from 'react-native-vector-icons/FontAwesome';
import DateTimeInput from '../../components/DateTimeInput';
import DatePickerInput from '../../components/DatePickerInput';

const EditTestResultScreen = ({ route, navigation }) => {
    const { patientId, test } = route.params;
    const [patient, setPatient] = useState(null);
    const [date, setDate] = useState(new Date(test.date.seconds * 1000));
    const [time, setTime] = useState(new Date(test.date.seconds * 1000));
    const [testValues, setTestValues] = useState({});
    const [loading, setLoading] = useState(false);

    const fetchPatient = async () => {
        try {
            const patientDoc = doc(db, 'users', patientId);
            const snap = await getDoc(patientDoc);
            if (!snap.exists()) {
                Alert.alert('Hata', 'Hasta bulunamadı.');
                navigation.goBack();
                return;
            }
            setPatient({ id: snap.id, ...snap.data() });
        } catch (error) {
            console.error('Hasta bilgisi alınırken hata:', error);
            Alert.alert('Hata', 'Hasta bilgisi alınamadı.');
        }
    };

    useEffect(() => {
        fetchPatient();
        const initialValues = {};
        test.tests.forEach((t) => {
            initialValues[t.name] = t.value.toString();
        });
        setTestValues(initialValues);
    }, [test]);

    const convertUnits = (value, fromUnit, toUnit) => {
        if (fromUnit === toUnit) return value;
        if (fromUnit === "g/L" && toUnit === "mg/L") {
            return value * 1000;
        }
        if (fromUnit === "mg/L" && toUnit === "g/L") {
            return value / 1000;
        }
        return value;
    };

    const saveUpdatedTest = async () => {
        if (!patient) return;

        const ageInMonths = calculateAgeInMonths(patient.birthDate);

        setLoading(true);

        try {
            const guidesSnap = await getDocs(collection(db, 'guides'));
            const guides = guidesSnap.docs.map((doc) => ({ id: doc.id, ...doc.data() }));

            const combinedDateTime = new Date(
                date.getFullYear(),
                date.getMonth(),
                date.getDate(),
                time.getHours(),
                time.getMinutes(),
                time.getSeconds()
            );

            const updatedTests = TEST_TYPES.map((testName) => {
                const inputValue = parseFloat(testValues[testName]);
                if (isNaN(inputValue)) return null;

                const evaluations = [];

                guides.forEach((guide) => {
                    guide.testTypes.forEach((testType) => {
                        if (testType.name === testName) {
                            const ageGroup = testType.ageGroups.find((ag) =>
                                isAgeInRange(ageInMonths, ag.ageRange)
                            );

                            if (ageGroup) {
                                const convertedValue = convertUnits(
                                    inputValue,
                                    "g/L",
                                    guide.unit || "mg/L"
                                );

                                const { referenceMin, referenceMax } = ageGroup;
                                let status = "Normal";
                                if (convertedValue < referenceMin) status = "Düşük";
                                else if (convertedValue > referenceMax) status = "Yüksek";

                                evaluations.push({
                                    guideName: guide.name || "Bilinmeyen Klavuz",
                                    referenceMin,
                                    referenceMax,
                                    status,
                                    unit: guide.unit || "mg/L",
                                });
                            }
                        }
                    });
                });

                return {
                    name: testName,
                    value: inputValue,
                    evaluations,
                };
            }).filter(Boolean);

            const testRef = doc(db, 'users', patientId, 'results', test.id);
            await updateDoc(testRef, {
                date: combinedDateTime,
                tests: updatedTests,
            });

            Alert.alert('Başarılı', 'Tahlil sonuçları başarıyla güncellendi.');
            navigation.goBack();
        } catch (error) {
            console.error('Tahlil güncellenirken hata:', error);
            Alert.alert('Hata', 'Tahlil güncellenemedi.');
        } finally {
            setLoading(false);
        }
    };

    const ageInMonths = patient ? calculateAgeInMonths(patient.birthDate) : null;

    return (
        <ScrollView contentContainerStyle={styles.container}>


            <View style={styles.section}>
                <DatePickerInput
                    label="Tarih"
                    date={date}
                    setDate={setDate}
                />
                <DateTimeInput
                    label="Saat"
                    dateTime={time}
                    setDateTime={setTime}
                    mode="time"
                />
            </View>

            <View style={styles.section}>
                <Text style={styles.sectionTitle}>Test Değerleri (g/L)</Text>
                {TEST_TYPES.map((testName) => (
                    <View key={testName} style={styles.testRow}>
                        <Icon name="flask" size={18} color="#333" style={styles.icon} />
                        <Text style={styles.testName}>{testName}:</Text>
                        <TextInput
                            placeholder={`Örn. ${testName} değeri (g/L)`}
                            value={testValues[testName] || ''}
                            onChangeText={(val) => setTestValues({ ...testValues, [testName]: val })}
                            keyboardType="numeric"
                            style={styles.input}
                        />
                    </View>
                ))}
            </View>

            <View style={styles.buttonContainer}>
                <TouchableOpacity
                    style={[styles.saveButton, loading && styles.buttonDisabled]}
                    onPress={saveUpdatedTest}
                    disabled={loading}
                >
                    <Text style={styles.saveButtonText}>
                        {loading ? "Kaydediliyor..." : "Kaydet"}
                    </Text>
                </TouchableOpacity>
                {loading && <ActivityIndicator size="small" color="#0000ff" style={styles.loader} />}
            </View>
        </ScrollView>
    );
};

export default EditTestResultScreen;

const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        padding: 20,
        backgroundColor: '#f5f5f5',
    },
    infoRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 8,
    },
    icon: {
        marginRight: 8,
        width: 20,
        textAlign: 'center',
    },
    label: {
        fontSize: 14,
        fontWeight: '600',
        color: '#333',
        width: 100,
    },
    value: {
        fontSize: 14,
        color: '#555',
        flex: 1,
    },
    section: {
        backgroundColor: '#fff',
        padding: 12,
        borderRadius: 8,
        marginBottom: 15,
        elevation: 1,
    },
    sectionTitle: {
        fontSize: 16,
        fontWeight: '700',
        marginBottom: 10,
        color: '#333',
    },
    testRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 10,
    },
    testName: {
        fontSize: 14,
        fontWeight: '600',
        color: '#333',
        width: 100,
    },
    input: {
        borderWidth: 1,
        borderColor: '#ccc',
        flex: 1,
        paddingVertical: 6,
        paddingHorizontal: 8,
        borderRadius: 5,
        backgroundColor: '#fafafa',
        fontSize: 14,
    },
    buttonContainer: {
        alignItems: 'center',
        marginBottom: 20,
    },
    saveButton: {
        backgroundColor: '#FF5722',
        paddingVertical: 10,
        paddingHorizontal: 40,
        borderRadius: 5,
    },
    saveButtonText: {
        color: '#fff',
        fontSize: 16,
        fontWeight: '600',
    },
    buttonDisabled: {
        backgroundColor: '#FF8A65',
    },
    loader: {
        marginTop: 8,
    },
});
