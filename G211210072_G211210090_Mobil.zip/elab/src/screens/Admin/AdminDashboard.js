// ./src/screens/Admin/AdminDashboard.js
import React, { useContext, useState, useEffect, useRef } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    SafeAreaView,
    ScrollView,
    Animated,
    Dimensions,
    TouchableWithoutFeedback,
    Alert,
} from 'react-native';
import { logoutUser } from '../../services/authService';
import { AuthContext } from '../../contexts/AuthContext';

import Icon from 'react-native-vector-icons/Ionicons';
import { collection, query, where, onSnapshot, collectionGroup } from 'firebase/firestore';
import { db } from '../../firebase';

const { width } = Dimensions.get('window');
const MENU_WIDTH = width * 0.7;

const AdminDashboard = ({ navigation }) => {
    const { user, setUser } = useContext(AuthContext);
    const [menuOpen, setMenuOpen] = useState(false);
    const [testCount, setTestCount] = useState(0);
    const [patientCount, setPatientCount] = useState(0);
    const animatedValue = useRef(new Animated.Value(-MENU_WIDTH)).current;

    useEffect(() => {
        const usersQuery = query(collection(db, 'users'), where('role', '==', 'patient'));
        const unsubscribeUsers = onSnapshot(usersQuery, (snapshot) => {
            setPatientCount(snapshot.size);
        });

        const testResultsQuery = query(collectionGroup(db, 'results'));
        const unsubscribeTests = onSnapshot(testResultsQuery, (snapshot) => {
            setTestCount(snapshot.size);
        });

        return () => {
            unsubscribeUsers();
            unsubscribeTests();
        };
    }, []);

    const openMenu = () => {
        setMenuOpen(true);
        Animated.timing(animatedValue, {
            toValue: 0,
            duration: 300,
            useNativeDriver: false,
        }).start();
    };

    const closeMenu = () => {
        Animated.timing(animatedValue, {
            toValue: -MENU_WIDTH,
            duration: 300,
            useNativeDriver: false,
        }).start(() => {
            setMenuOpen(false);
        });
    };

    const toggleMenu = () => {
        if (menuOpen) {
            closeMenu();
        } else {
            openMenu();
        }
    };

    const handleLogout = async () => {
        await logoutUser();
        setUser(null);
    };

    const confirmLogout = () => {
        Alert.alert(
            'Çıkış Yap',
            'Çıkış yapmak istediğinizden emin misiniz?',
            [
                { text: 'İptal', style: 'cancel' },
                { text: 'Evet', onPress: handleLogout },
            ],
            { cancelable: false }
        );
    };

    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.header}>
                <TouchableOpacity onPress={toggleMenu}>
                    <Icon name="menu" size={30} color="#000" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Admin Paneli</Text>
                <View style={{ width: 30 }} />
            </View>

            {menuOpen && (
                <TouchableWithoutFeedback onPress={closeMenu}>
                    <View style={styles.overlay} />
                </TouchableWithoutFeedback>
            )}

            <Animated.View
                style={[
                    styles.menu,
                    {
                        transform: [{ translateX: animatedValue }],
                    },
                ]}
            >
                <ScrollView contentContainerStyle={styles.menuContent}>
                    <TouchableOpacity
                        style={styles.menuItem}
                        onPress={() => {
                            toggleMenu();
                            navigation.navigate('GuideManagement');
                        }}
                    >
                        <Icon name="book" size={20} color="#000" />
                        <Text style={styles.menuText}>Klavuz Yönetim</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={styles.menuItem}
                        onPress={() => {
                            toggleMenu();
                            navigation.navigate('QuickTestSearch');
                        }}
                    >
                        <Icon name="search" size={20} color="#000" />
                        <Text style={styles.menuText}>Hızlı Arama</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={styles.menuItem}
                        onPress={() => {
                            toggleMenu();
                            navigation.navigate('PatientManagement');
                        }}
                    >
                        <Icon name="medkit" size={20} color="#000" />
                        <Text style={styles.menuText}>Hasta Yönetimi</Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                        style={styles.menuItem}
                        onPress={() => {
                            toggleMenu();
                            navigation.navigate('QuickTestResult');
                        }}
                    >
                        <Icon name="stats-chart" size={20} color="#000" />
                        <Text style={styles.menuText}>Hızlı Tahlil Sorgulama</Text>
                    </TouchableOpacity>
                </ScrollView>
                <View style={styles.logoutContainer}>
                    <TouchableOpacity
                        style={styles.logoutButton}
                        onPress={confirmLogout}
                    >
                        <Icon name="log-out" size={20} color="#fff" />
                        <Text style={styles.logoutText}>Çıkış Yap</Text>
                    </TouchableOpacity>
                </View>
            </Animated.View>

            <ScrollView contentContainerStyle={styles.content}>
                <Text style={styles.welcomeText}>Hoşgeldiniz, Dr. {user?.name}!</Text>
                <View style={styles.cardContainer}>
                    <View style={styles.card}>
                        <Icon name="flask" size={40} color="#4CAF50" />
                        <Text style={styles.cardTitle}>Toplam Test Sayısı</Text>
                        <Text style={styles.cardCount}>{testCount}</Text>
                    </View>
                    <View style={styles.card}>
                        <Icon name="medkit" size={40} color="#2196F3" />
                        <Text style={styles.cardTitle}>Toplam Hasta Sayısı</Text>
                        <Text style={styles.cardCount}>{patientCount}</Text>
                    </View>
                </View>
            </ScrollView>
        </SafeAreaView>
    );
};

export default AdminDashboard;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f9f9f9',
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: 15,
        paddingTop: 50,
        backgroundColor: '#fff',
        elevation: 4,
    },
    headerTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        textAlign: 'center',
        flex: 1,
    },
    menu: {
        position: 'absolute',
        top: 0,
        bottom: 0,
        left: 0,
        width: MENU_WIDTH,
        backgroundColor: '#fff',
        elevation: 10,
        zIndex: 1000,
        borderRightWidth: 1,
        borderColor: '#ccc',
    },
    menuContent: {
        flexGrow: 1,
        justifyContent: 'flex-start',
        paddingTop: 50,
    },
    menuItem: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: 20,
        paddingHorizontal: 20,
        borderBottomWidth: 1,
        borderBottomColor: '#f1f1f1',
    },
    menuText: {
        fontSize: 16,
        marginLeft: 10,
        color: '#000',
    },
    logoutContainer: {
        borderTopWidth: 1,
        borderTopColor: '#f1f1f1',
        padding: 20,
    },
    logoutButton: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#ff4d4d',
        paddingVertical: 15,
        paddingHorizontal: 20,
        borderRadius: 5,
    },
    logoutText: {
        fontSize: 16,
        color: '#fff',
        marginLeft: 10,
        fontWeight: 'bold',
    },
    overlay: {
        position: 'absolute',
        top: 0,
        left: 0,
        width: width,
        height: '100%',
        backgroundColor: 'rgba(0,0,0,0.3)',
        zIndex: 500,
    },
    content: {
        flexGrow: 1,
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: 20,
        paddingVertical: 40,
    },
    welcomeText: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 30,
    },
    infoText: {
        fontSize: 18,
        textAlign: 'center',
        marginBottom: 20,
        color: '#666',
    },
    cardContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        width: '100%',
    },
    card: {
        backgroundColor: '#fff',
        width: '48%',
        padding: 20,
        borderRadius: 10,
        alignItems: 'center',
        elevation: 3,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 5,
    },
    cardTitle: {
        fontSize: 16,
        fontWeight: '600',
        marginTop: 10,
        textAlign: 'center',
    },
    cardCount: {
        fontSize: 24,
        fontWeight: 'bold',
        marginTop: 5,
        color: '#333',
    },
});
