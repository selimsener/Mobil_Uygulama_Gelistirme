// ./screens/Doctor/TestTypeDetailScreen.js
import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    Alert,
    StyleSheet,
    Button,
    FlatList,
    TouchableOpacity,
} from 'react-native';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { db } from '../../firebase';
import Ionicons from '@expo/vector-icons/Ionicons';

const TestTypeDetailScreen = ({ route, navigation }) => {
    const { guideId, testTypeName } = route.params;
    const [testType, setTestType] = useState(null);
    const [guide, setGuide] = useState(null);

    const fetchData = async () => {
        const docRef = doc(db, 'guides', guideId);
        const docSnap = await getDoc(docRef);
        if (!docSnap.exists()) {
            Alert.alert('Hata', 'Klavuz bulunamadı');
            navigation.goBack();
            return;
        }
        const g = { id: docSnap.id, ...docSnap.data() };
        setGuide(g);
        const tt = g.testTypes.find((t) => t.name === testTypeName);
        if (!tt) {
            Alert.alert('Hata', 'Test tipi bulunamadı');
            navigation.goBack();
            return;
        }
        setTestType(tt);
    };

    const confirmRemoveAgeGroup = (index) => {
        const ageRange = testType.ageGroups[index].ageRange;
        Alert.alert(
            'Yaş Grubu Silme',
            `${ageRange} yaş grubunu silmek istediğinize emin misiniz?`,
            [
                { text: 'İptal', style: 'cancel' },
                {
                    text: 'Sil',
                    style: 'destructive',
                    onPress: () => removeAgeGroup(index),
                },
            ]
        );
    };

    const removeAgeGroup = async (index) => {
        if (!guide || !testType) return;
        const ttIndex = guide.testTypes.findIndex((t) => t.name === testTypeName);
        const newAgeGroups = [...testType.ageGroups];
        newAgeGroups.splice(index, 1);

        const updatedTestTypes = [...guide.testTypes];
        updatedTestTypes[ttIndex] = { ...testType, ageGroups: newAgeGroups };

        await updateDoc(doc(db, 'guides', guide.id), { testTypes: updatedTestTypes });
        setTestType({ ...testType, ageGroups: newAgeGroups });
    };

    useEffect(() => {
        const unsubscribe = navigation.addListener('focus', fetchData);
        return unsubscribe;
    }, [navigation]);

    if (!testType) return null;

    return (
        <View style={styles.container}>
            <View style={styles.header}>
                <Ionicons name="flask-outline" size={24} color="#333" style={styles.headerIcon} />
                <Text style={styles.title}>{testType.name} - Yaş Grupları</Text>
            </View>

            <View style={styles.addButtonContainer}>
                <Button
                    title="Yaş Grubu Ekle"
                    onPress={() => navigation.navigate('AddAgeGroup', { guideId, testTypeName })}
                    color="#007BFF"
                />
            </View>

            <FlatList
                data={testType.ageGroups}
                keyExtractor={(item, index) => index.toString()}
                ListEmptyComponent={<Text style={styles.empty}>Hiç yaş grubu yok.</Text>}
                renderItem={({ item, index }) => (
                    <View style={styles.ageGroupRow}>
                        <View style={styles.ageInfo}>
                            <Ionicons name="people-outline" size={18} color="#333" style={styles.ageIcon} />
                            <Text style={styles.ageText}>
                                {item.ageRange} yaş aralığı
                            </Text>
                        </View>
                        <Text style={styles.rangeText}>
                            Min: {item.referenceMin.toFixed(2)}, Max: {item.referenceMax.toFixed(2)}
                        </Text>
                        <View style={styles.actions}>
                            <Button
                                title="Düzenle"
                                color="#4CAF50"
                                onPress={() =>
                                    navigation.navigate('EditAgeGroup', {
                                        guideId,
                                        testTypeName,
                                        ageGroup: item,
                                        index,
                                    })
                                }
                            />
                            <Button
                                title="Sil"
                                color="#dc3545"
                                onPress={() => confirmRemoveAgeGroup(index)}
                            />
                        </View>
                    </View>
                )}
            />
        </View>
    );
};

export default TestTypeDetailScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 16,
        backgroundColor: '#f5f5f5',
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 15,
    },
    headerIcon: {
        marginRight: 8,
    },
    title: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#333',
    },
    addButtonContainer: {
        marginBottom: 10,
        alignSelf: 'flex-start',
    },
    empty: {
        textAlign: 'center',
        marginTop: 20,
        color: '#888',
    },
    ageGroupRow: {
        backgroundColor: '#fff',
        borderRadius: 8,
        padding: 12,
        marginBottom: 10,
        elevation: 1,
    },
    ageInfo: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 5,
    },
    ageIcon: {
        marginRight: 5,
    },
    ageText: {
        fontSize: 15,
        fontWeight: '600',
        color: '#333',
    },
    rangeText: {
        fontSize: 14,
        color: '#555',
        marginBottom: 5,
    },
    actions: {
        flexDirection: 'row',
        justifyContent: 'flex-end',
        gap: 10,
    },
});
