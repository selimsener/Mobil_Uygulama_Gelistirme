// ./screens/Doctor/GuideManagementScreen.js
import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    FlatList,
    TouchableOpacity,
    StyleSheet,
    Alert,
    ActivityIndicator,
    Button,
} from 'react-native';
import { collection, getDocs, doc, deleteDoc, addDoc } from 'firebase/firestore';
import { db } from '../../firebase';
import guidesData from '../../../assets/klavuzVerileri.json'; // JSON verisini import ediyoruz
import Ionicons from '@expo/vector-icons/Ionicons'; // İkon için gerekli kütüphane

const GuideManagementScreen = ({ navigation }) => {
    const [guides, setGuides] = useState([]);
    const [uploading, setUploading] = useState(false); // Yükleme durumunu takip ediyoruz

    const fetchGuides = async () => {
        try {
            const querySnapshot = await getDocs(collection(db, 'guides'));
            const guidesList = [];
            querySnapshot.forEach((docSnap) => {
                guidesList.push({ id: docSnap.id, ...docSnap.data() });
            });
            setGuides(guidesList);
        } catch (error) {
            console.error("Firestore'dan veri çekilirken hata oluştu:", error);
            Alert.alert('Hata', 'Klavuzlar yüklenirken bir hata oluştu.');
        }
    };

    const deleteGuide = async (guideId, guideName) => {
        Alert.alert(
            'Klavuzu Sil',
            `${guideName} isimli klavuzu silmek istediğinize emin misiniz?`,
            [
                { text: 'İptal', style: 'cancel' },
                {
                    text: 'Sil',
                    style: 'destructive',
                    onPress: async () => {
                        try {
                            await deleteDoc(doc(db, 'guides', guideId));
                            setGuides((prev) => prev.filter((guide) => guide.id !== guideId));
                            Alert.alert('Başarılı', `${guideName} isimli klavuz başarıyla silindi.`);
                        } catch (error) {
                            console.error("Klavuz silinirken hata oluştu:", error);
                            Alert.alert('Hata', `${guideName} isimli klavuz silinemedi.`);
                        }
                    },
                },
            ]
        );
    };

    const uploadGuidesToFirestore = async () => {
        setUploading(true);
        try {
            const guidesCollection = collection(db, 'guides');
            for (const guide of guidesData.guides) {
                const processedTestTypes = guide.testTypes.map((testType) => ({
                    ...testType,
                    ageGroups: testType.ageGroups.map((ageGroup) => {
                        const { geometricMean, standardDeviation, minValue, maxValue } = ageGroup;
                        return {
                            ...ageGroup,
                            referenceMin: geometricMean && standardDeviation
                                ? geometricMean - standardDeviation
                                : minValue,
                            referenceMax: geometricMean && standardDeviation
                                ? geometricMean + standardDeviation
                                : maxValue,
                        };
                    }),
                }));

                await addDoc(guidesCollection, {
                    name: guide.name,
                    description: guide.description,
                    unit: guide.unit,
                    type: guide.type,
                    testTypes: processedTestTypes,
                });
            }
            Alert.alert('Başarılı', 'Klavuzlar başarıyla yüklendi.');
            fetchGuides(); // Yeni eklenen klavuzları çek
        } catch (error) {
            console.error('Firestore yüklenirken hata oluştu:', error);
            Alert.alert('Hata', 'Klavuzlar yüklenemedi.');
        }
        setUploading(false);
    };

    const confirmUpload = () => {
        Alert.alert(
            'JSON Yükle',
            'JSON dosyasından klavuzları Firestore’a yüklemek istediğinize emin misiniz?',
            [
                { text: 'İptal', style: 'cancel' },
                {
                    text: 'Evet',
                    onPress: uploadGuidesToFirestore,
                },
            ]
        );
    };

    useEffect(() => {
        const unsubscribe = navigation.addListener('focus', fetchGuides);
        return unsubscribe;
    }, [navigation]);

    return (
        <View style={styles.container}>
            <View style={styles.header}>
                <Text style={styles.title}>Klavuz Yönetimi</Text>
                {uploading ? (
                    <ActivityIndicator size="small" color="#007BFF" />
                ) : (
                    <TouchableOpacity onPress={confirmUpload} style={styles.iconButton}>
                        <Ionicons name="cloud-upload-outline" size={24} color="#007BFF" />
                    </TouchableOpacity>
                )}
            </View>

            <TouchableOpacity
                style={styles.addButton}
                onPress={() => navigation.navigate('AddGuide')}
            >
                <Ionicons name="add-circle-outline" size={20} color="#fff" style={{ marginRight: 5 }} />
                <Text style={styles.addButtonText}>Yeni Klavuz Ekle</Text>
            </TouchableOpacity>

            <FlatList
                data={guides}
                keyExtractor={(item) => item.id}
                ListEmptyComponent={<Text style={styles.empty}>Hiç klavuz yok.</Text>}
                renderItem={({ item }) => (
                    <View style={styles.guideItem}>
                        <TouchableOpacity
                            onPress={() => navigation.navigate('GuideDetail', { guideId: item.id })}
                            style={styles.guideInfo}
                        >
                            <View style={styles.guideHeader}>
                                <Ionicons name="book-outline" size={18} color="#333" style={styles.guideIcon} />
                                <Text style={styles.guideName}>{item.name}</Text>
                            </View>
                            <Text style={styles.guideDesc}>{item.description}</Text>
                        </TouchableOpacity>
                        <View style={styles.actionButtons}>
                            <TouchableOpacity
                                style={[styles.button, styles.editButton]}
                                onPress={() => navigation.navigate('EditGuide', { guide: item })}
                            >
                                <Ionicons name="create-outline" size={16} color="#fff" style={styles.btnIcon} />
                                <Text style={styles.btnText}>Düzenle</Text>
                            </TouchableOpacity>
                            <TouchableOpacity
                                style={[styles.button, styles.deleteButton]}
                                onPress={() => deleteGuide(item.id, item.name)}
                            >
                                <Ionicons name="trash-outline" size={16} color="#fff" style={styles.btnIcon} />
                                <Text style={styles.btnText}>Sil</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                )}
            />
        </View>
    );
};

export default GuideManagementScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        backgroundColor: '#f5f5f5',
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 15,
    },
    title: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#333',
    },
    iconButton: {
        padding: 5,
    },
    addButton: {
        flexDirection: 'row',
        backgroundColor: '#007BFF',
        padding: 10,
        borderRadius: 6,
        alignItems: 'center',
        marginBottom: 15,
    },
    addButtonText: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 14,
    },
    empty: {
        textAlign: 'center',
        marginTop: 30,
        color: '#888',
        fontSize: 16,
    },
    guideItem: {
        backgroundColor: '#fff',
        padding: 15,
        marginBottom: 12,
        borderRadius: 8,
        elevation: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    guideInfo: {
        flex: 1,
        marginRight: 10,
    },
    guideHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 5,
    },
    guideIcon: {
        marginRight: 5,
    },
    guideName: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#333',
    },
    guideDesc: {
        fontSize: 14,
        color: '#555',
    },
    actionButtons: {
        justifyContent: 'space-between',
        alignItems: 'flex-end',
    },
    button: {
        flexDirection: 'row',
        borderRadius: 5,
        paddingHorizontal: 10,
        paddingVertical: 6,
        marginBottom: 5,
        alignItems: 'center',
    },
    editButton: {
        backgroundColor: '#4CAF50',
    },
    deleteButton: {
        backgroundColor: '#F44336',
    },
    btnIcon: {
        marginRight: 5,
    },
    btnText: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 14,
    },
});
