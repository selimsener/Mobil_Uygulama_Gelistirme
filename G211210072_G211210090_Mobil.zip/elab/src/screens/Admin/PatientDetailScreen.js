// ./src/screens/Patient/PatientDetailScreen.js
import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    FlatList,
    StyleSheet,
    ActivityIndicator,
    Alert,
    TextInput,
} from 'react-native';
import { doc, getDoc, collection, query, orderBy, getDocs, deleteDoc } from 'firebase/firestore';
import { db } from '../../firebase';
import Icon from "react-native-vector-icons/Ionicons";

import { calculateAgeInMonths } from '../../utils/ageCalculator';

// Yardımcı Fonksiyonlar
const getStatusColor = (status) => {
    switch (status) {
        case 'Yüksek':
            return 'red';
        case 'Normal':
            return 'green';
        case 'Düşük':
            return 'orange';
        default:
            return 'grey';
    }
};

const getStatusIcon = (status) => {
    switch (status) {
        case 'Yüksek':
            return 'arrow-up-circle';
        case 'Normal':
            return 'checkmark-circle';
        case 'Düşük':
            return 'arrow-down-circle';
        default:
            return 'help-circle';
    }
};



const formatNumber = (num) => {
    return Number(num).toFixed(2).replace('.', ',');
};

/**
 * g/L -> mg/L dönüşümü için basit bir fonksiyon.
 * g/L değeri * 1000 = mg/L
 */
const convertToMgL = (valueInGL) => {
    return valueInGL * 1000;
};

// Patient Detail Screen
const PatientDetailScreen = ({ route, navigation }) => {
    const { patientId } = route.params;
    const [patient, setPatient] = useState(null);
    const [results, setResults] = useState([]);
    const [allResults, setAllResults] = useState([]);
    const [loading, setLoading] = useState(false);
    const [searchText, setSearchText] = useState('');
    const [sortOrder, setSortOrder] = useState('desc'); // 'asc' veya 'desc'

    const fetchPatientDetails = async () => {
        setLoading(true);
        try {
            // Hasta bilgileri
            const docRef = doc(db, 'users', patientId);
            const docSnap = await getDoc(docRef);
            if (docSnap.exists()) {
                setPatient(docSnap.data());
            } else {
                Alert.alert('Hata', 'Hasta bulunamadı.');
                setPatient(null);
            }

            // Tahlil sonuçları
            const resultsQuery = query(
                collection(db, 'users', patientId, 'results'),
                orderBy('date', sortOrder)
            );
            const resultsSnap = await getDocs(resultsQuery);
            const resultsList = [];
            resultsSnap.forEach((docSnap) =>
                resultsList.push({ id: docSnap.id, ...docSnap.data() })
            );
            setResults(resultsList);
            setAllResults(resultsList);
        } catch (error) {
            console.error('Error fetching details:', error);
            Alert.alert('Error', 'Hasta bilgileri yüklenirken hata oluştu.');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        const unsubscribe = navigation.addListener('focus', fetchPatientDetails);
        return unsubscribe;
    }, [navigation]);

    // sortOrder değiştiğinde veriyi yeniden çek
    useEffect(() => {
        fetchPatientDetails();
    }, [sortOrder]);

    const handleDeleteTest = async (testId) => {
        Alert.alert(
            'Tahlili Sil',
            'Bu tahlili silmek istediğinize emin misiniz?',
            [
                { text: 'İptal', style: 'cancel' },
                {
                    text: 'Sil',
                    style: 'destructive',
                    onPress: async () => {
                        try {
                            await deleteDoc(doc(db, 'users', patientId, 'results', testId));
                            Alert.alert('Başarılı', 'Tahlil başarıyla silindi.');
                            fetchPatientDetails();
                        } catch (error) {
                            console.error('Error deleting test:', error);
                            Alert.alert('Hata', 'Tahlil silinemedi.');
                        }
                    },
                },
            ]
        );
    };

    const handleEditTest = (test) => {
        navigation.navigate('EditTestResult', { patientId, test });
    };

    const handleViewDetails = (testId) => {
        navigation.navigate('TestDetail', { patientId, testId });
    };

    const handleSearch = () => {
        if (searchText.trim() === '') {
            setResults(allResults);
            return;
        }

        const filteredResults = allResults.filter((item) => {
            const searchTerm = searchText.toLowerCase();
            const testNameMatch = item.tests && item.tests.some((t) =>
                t.name.toLowerCase().includes(searchTerm)
            );
            const dateMatch =
                item.date &&
                new Date(item.date.seconds * 1000).toLocaleDateString().includes(searchTerm);
            return testNameMatch || dateMatch;
        });
        setResults(filteredResults);
    };

    const toggleSortOrder = () => {
        setSortOrder((prevOrder) => (prevOrder === 'asc' ? 'desc' : 'asc'));
    };

    if (loading) {
        return (
            <View style={styles.loaderContainer}>
                <ActivityIndicator size="large" color="#007BFF" />
            </View>
        );
    }

    // Hasta'nın ay olarak yaşını hesapla
    const ageInMonths = patient?.birthDate
        ? calculateAgeInMonths(patient.birthDate)
        : null;

    return (
        <View style={styles.container}>
            {/* Hasta Bilgi Kartı */}
            {patient && (
                <View style={styles.patientCard}>
                    <Text style={styles.patientCardTitle}>Hasta Bilgileri</Text>
                    <View style={styles.patientInfoRow}>
                        <Icon name="person" size={18} color="#333" style={styles.infoIcon} />
                        <Text style={styles.infoLabel}>Ad:</Text>
                        <Text style={styles.infoValue}>{patient.name || 'Belirsiz'}</Text>
                    </View>
                    <View style={styles.patientInfoRow}>
                        <Icon name="card" size={18} color="#333" style={styles.infoIcon} />
                        <Text style={styles.infoLabel}>TC:</Text>
                        <Text style={styles.infoValue}>{patient.tc || 'Belirsiz'}</Text>
                    </View>
                    <View style={styles.patientInfoRow}>
                        <Icon name="calendar" size={18} color="#333" style={styles.infoIcon} />
                        <Text style={styles.infoLabel}>Yaş (Aylık):</Text>
                        <Text style={styles.infoValue}>
                            {ageInMonths !== null ? `${ageInMonths} ay` : 'Belirsiz'}
                        </Text>
                    </View>
                </View>
            )}

            {/* Butonlar - Yeni Tahlil Ekle ve Sıralama */}
            <View style={styles.buttonRow}>
                <TouchableOpacity
                    style={styles.addButton}
                    onPress={() => navigation.navigate('AddTestResult', { patientId })}
                >
                    <Text style={styles.addButtonText}>Yeni Tahlil Ekle</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.sortButton} onPress={toggleSortOrder}>
                    <Text style={styles.sortButtonText}>
                        Sırala ({sortOrder === 'asc' ? 'En Eski' : 'En Yeni'})
                    </Text>
                </TouchableOpacity>
            </View>

            {/* Arama Alanı */}
            <View style={styles.searchContainer}>
                <TextInput
                    placeholder="Ara (test adı veya tarih)..."
                    value={searchText}
                    onChangeText={setSearchText}
                    style={styles.searchInput}
                />
                <TouchableOpacity style={styles.searchButton} onPress={handleSearch}>
                    <Icon name="search" size={18} color="#fff" style={{ marginRight: 5 }} />
                    <Text style={styles.searchButtonText}>Ara</Text>
                </TouchableOpacity>
            </View>

            {/* Tahlil Sonuç Listesi */}
            <FlatList
                data={results}
                keyExtractor={(item) => item.id}
                ListEmptyComponent={
                    <Text style={styles.empty}>Tahlil sonuçları bulunamadı.</Text>
                }
                renderItem={({ item }) => (
                    <View style={styles.resultCard}>
                        <TouchableOpacity
                            onPress={() => handleViewDetails(item.id)}
                            style={styles.resultHeader}
                        >
                            <Text style={styles.resultDate}>
                                Tarih & Saat:{' '}
                                {item.date
                                    ? new Date(item.date.seconds * 1000).toLocaleString()
                                    : 'Belirsiz'}
                            </Text>
                            <Icon name="chevron-forward" size={20} color="#007BFF" />
                        </TouchableOpacity>
                        {item.tests && item.tests.length > 0 ? (
                            item.tests.map((test, index) => {
                                // Test değeri hem g/L hem de mg/L olarak
                                const gLValue = Number(test.value) || 0;
                                const mgLValue = convertToMgL(gLValue);

                                return (
                                    <View key={index} style={styles.testContainer}>
                                        <View style={styles.testHeader}>
                                            <Icon
                                                name="flask"
                                                size={18}
                                                color="#333"
                                                style={{ marginRight: 5 }}
                                            />
                                            <Text style={styles.testName}>{test.name}:</Text>
                                        </View>
                                        {/* Hem g/L hem de mg/L'yi gösterelim */}
                                        <Text style={styles.testValue}>
                                            {formatNumber(gLValue)} g/L {'  '}
                                            ({formatNumber(mgLValue)} mg/L)
                                        </Text>

                                        {test.evaluations && test.evaluations.length > 0 ? (
                                            test.evaluations.map((evalItem, evalIndex) => (
                                                <View
                                                    key={evalIndex}
                                                    style={styles.evaluationContainer}
                                                >
                                                    <Text style={styles.guideName}>
                                                        Klavuz: {evalItem.guideName}
                                                    </Text>
                                                    <Text style={styles.evalText}>
                                                        Klavuz birimi:{' '}
                                                        {evalItem.unit || 'Belirtilmemiş'}
                                                    </Text>
                                                    <Text style={styles.evalText}>
                                                        Referans Aralığı:{' '}
                                                        {formatNumber(evalItem.referenceMin)} -{' '}
                                                        {formatNumber(evalItem.referenceMax)}
                                                    </Text>
                                                    {/* Durum + İkon */}
                                                    <View style={styles.statusRow}>
                                                        <Text style={styles.statusText}>Durum: </Text>
                                                        <Icon
                                                            name={getStatusIcon(evalItem.status)}
                                                            size={16}
                                                            color={getStatusColor(evalItem.status)}
                                                            style={styles.statusIcon}
                                                        />
                                                        <Text
                                                            style={[
                                                                styles.statusValue,
                                                                {
                                                                    color: getStatusColor(evalItem.status),
                                                                },
                                                            ]}
                                                        >
                                                            {evalItem.status}
                                                        </Text>
                                                    </View>
                                                </View>
                                            ))
                                        ) : (
                                            <Text style={styles.noEvaluations}>
                                                Değerlendirme bulunmamaktadır.
                                            </Text>
                                        )}
                                    </View>
                                );
                            })
                        ) : (
                            <Text style={styles.noTestsText}>Test bulunmamaktadır.</Text>
                        )}
                        <View style={styles.actionButtons}>
                            <TouchableOpacity
                                style={styles.editButton}
                                onPress={() => handleEditTest(item)}
                            >
                                <Text style={styles.editButtonText}>Düzenle</Text>
                            </TouchableOpacity>
                            <TouchableOpacity
                                style={styles.deleteButton}
                                onPress={() => handleDeleteTest(item.id)}
                            >
                                <Text style={styles.deleteButtonText}>Sil</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                )}
            />
        </View>
    );
};

export default PatientDetailScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 16,
        backgroundColor: '#f5f5f5',
    },
    loaderContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#f5f5f5',
    },
    patientCard: {
        backgroundColor: '#fff',
        borderRadius: 8,
        marginBottom: 12,
        padding: 12,
        elevation: 1,
    },
    patientCardTitle: {
        fontSize: 16,
        fontWeight: 'bold',
        marginBottom: 8,
        color: '#333',
    },
    patientInfoRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 6,
    },
    infoIcon: {
        marginRight: 8,
        width: 20,
        textAlign: 'center',
    },
    infoLabel: {
        fontSize: 14,
        fontWeight: '600',
        width: 80,
        color: '#333',
    },
    infoValue: {
        fontSize: 14,
        color: '#555',
        flex: 1,
    },
    buttonRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 10,
    },
    addButton: {
        backgroundColor: '#28a745',
        paddingVertical: 10,
        paddingHorizontal: 15,
        borderRadius: 8,
        alignItems: 'center',
        flex: 0.48,
    },
    addButtonText: {
        color: '#fff',
        fontSize: 15,
        fontWeight: '600',
    },
    sortButton: {
        backgroundColor: '#6c757d',
        borderRadius: 8,
        paddingVertical: 10,
        paddingHorizontal: 15,
        alignItems: 'center',
        flex: 0.48,
    },
    sortButtonText: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 15,
    },
    searchContainer: {
        flexDirection: 'row',
        marginBottom: 10,
        alignItems: 'center',
    },
    searchInput: {
        flex: 1,
        borderWidth: 1,
        borderColor: '#ccc',
        paddingVertical: 8,
        paddingHorizontal: 10,
        borderRadius: 8,
        marginRight: 8,
        backgroundColor: '#fff',
    },
    searchButton: {
        flexDirection: 'row',
        backgroundColor: '#007BFF',
        borderRadius: 8,
        paddingVertical: 8,
        paddingHorizontal: 12,
        alignItems: 'center',
    },
    searchButtonText: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 14,
    },
    empty: {
        textAlign: 'center',
        color: '#888',
        marginTop: 20,
        fontSize: 15
    },
    resultCard: {
        backgroundColor: '#fff',
        borderRadius: 8,
        marginBottom: 12,
        padding: 12,
        elevation: 1,
    },
    resultHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 10,
    },
    resultDate: {
        fontSize: 15,
        fontWeight: '700',
        color: '#007BFF',
    },
    testContainer: {
        marginBottom: 8
    },
    testHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 5,
    },
    testName: {
        fontWeight: 'bold',
        fontSize: 16,
        color: '#333',
    },
    testValue: {
        fontSize: 16,
        marginBottom: 5,
        color: '#555',
    },
    evaluationContainer: {
        padding: 8,
        backgroundColor: '#e9ecef',
        borderRadius: 5,
        marginBottom: 5,
    },
    guideName: {
        fontWeight: 'bold',
        marginBottom: 3,
        fontSize: 15,
        color: '#333',
    },
    evalText: {
        fontSize: 14,
        color: '#555',
    },
    reference: {
        fontSize: 14,
        color: '#000',
        marginTop: 5,
    },
    statusRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 3,
    },
    statusText: {
        fontSize: 14,
        marginRight: 4,
        color: '#333',
    },
    statusIcon: {
        marginRight: 4,
    },
    statusValue: {
        fontSize: 14,
        fontWeight: 'bold',
        color: '#333',
    },
    noEvaluations: {
        fontSize: 14,
        color: '#888',
        marginTop: 5
    },
    noTestsText: {
        fontSize: 14,
        color: '#888',
        marginTop: 5
    },
    actionButtons: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: 8,
    },
    editButton: {
        backgroundColor: '#007BFF',
        padding: 10,
        borderRadius: 6,
        flex: 0.48,
        alignItems: 'center',
    },
    editButtonText: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 14,
    },
    deleteButton: {
        backgroundColor: '#dc3545',
        padding: 10,
        borderRadius: 6,
        flex: 0.48,
        alignItems: 'center',
    },
    deleteButtonText: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 14,
    },
    noDataText: {
        textAlign: 'center',
        color: '#888',
        marginTop: 10,
    },
});
