// ./screens/Doctor/AddGuideScreen.js
import React, { useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TextInput,
    Alert,
    Button,
} from 'react-native';
import { collection, addDoc } from 'firebase/firestore';
import { db } from '../../firebase';
import { Picker } from '@react-native-picker/picker';
import Ionicons from '@expo/vector-icons/Ionicons';

const AddGuideScreen = ({ navigation }) => {
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [unit, setUnit] = useState('');
    const [type, setType] = useState('');

    const addGuide = async () => {
        if (!name || !description || !unit || !type) {
            Alert.alert('Hata', 'Lütfen tüm alanları doldurun');
            return;
        }

        try {
            await addDoc(collection(db, 'guides'), {
                name,
                description,
                unit,
                type,
                testTypes: [],
            });
            Alert.alert('Başarılı', 'Klavuz eklendi');
            navigation.goBack();
        } catch (e) {
            console.error('Klavuz eklenemedi:', e);
            Alert.alert('Hata', 'Klavuz eklenemedi');
        }
    };

    return (
        <View style={styles.container}>
            <View style={styles.headerRow}>
                <Ionicons name="book-outline" size={24} color="#333" style={styles.icon} />
                <Text style={styles.title}>Yeni Klavuz Ekle</Text>
            </View>

            <TextInput
                placeholder="Klavuz Adı"
                style={styles.input}
                value={name}
                onChangeText={setName}
            />
            <TextInput
                placeholder="Açıklama"
                style={styles.input}
                value={description}
                onChangeText={setDescription}
            />

            <Text style={styles.label}>Klavuz Birimi:</Text>
            <View style={styles.pickerContainer}>
                <Picker
                    selectedValue={unit}
                    onValueChange={(itemValue) => setUnit(itemValue)}
                    style={styles.picker}
                >
                    <Picker.Item label="Birim Seçin" value="" />
                    <Picker.Item label="mg/L" value="mg/L" />
                    <Picker.Item label="g/L" value="g/L" />
                </Picker>
            </View>

            <Text style={styles.label}>Klavuz Tipi:</Text>
            <View style={styles.pickerContainer}>
                <Picker
                    selectedValue={type}
                    onValueChange={(itemValue) => setType(itemValue)}
                    style={styles.picker}
                >
                    <Picker.Item label="Klavuz Tipi Seçin" value="" />
                    <Picker.Item label="Geometric ve SD" value="geometric" />
                    <Picker.Item label="Min ve Max" value="minMax" />
                </Picker>
            </View>

            <Button title="Kaydet" onPress={addGuide} />
        </View>
    );
};

export default AddGuideScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        backgroundColor: '#f5f5f5',
    },
    headerRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 15,
    },
    icon: {
        marginRight: 8,
    },
    title: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#333',
    },
    input: {
        borderWidth: 1,
        borderColor: '#ccc',
        padding: 10,
        marginBottom: 10,
        backgroundColor: '#fff',
        borderRadius: 6,
    },
    label: {
        fontSize: 14,
        fontWeight: '600',
        marginBottom: 5,
        color: '#333',
    },
    pickerContainer: {
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 6,
        marginBottom: 15,
        backgroundColor: '#fff',
        overflow: 'hidden',
    },
    picker: {
        width: '100%',
    },
});
