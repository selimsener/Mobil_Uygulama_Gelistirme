import React, { useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TextInput,
    Alert,
    Button,
} from 'react-native';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../../firebase';
import { Picker } from '@react-native-picker/picker';
import Ionicons from '@expo/vector-icons/Ionicons';

const EditGuideScreen = ({ route, navigation }) => {
    const { guide } = route.params; // Geçerli klavuz bilgileri
    const [name, setName] = useState(guide.name);
    const [description, setDescription] = useState(guide.description);
    const [unit, setUnit] = useState(guide.unit);
    const [type, setType] = useState(guide.type);

    const updateGuide = async () => {
        if (!name || !description || !unit || !type) {
            Alert.alert('Hata', 'Lütfen tüm alanları doldurun');
            return;
        }

        try {
            const guideRef = doc(db, 'guides', guide.id);
            await updateDoc(guideRef, {
                name,
                description,
                unit,
                type,
            });
            Alert.alert('Başarılı', 'Klavuz güncellendi');
            navigation.goBack();
        } catch (error) {
            console.error('Klavuz güncellenirken hata:', error);
            Alert.alert('Hata', 'Klavuz güncellenemedi');
        }
    };

    return (
        <View style={styles.container}>
            <View style={styles.headerRow}>
                <Ionicons name="book-outline" size={24} color="#333" style={styles.icon} />
                <Text style={styles.headerTitle}>{guide.name}</Text>
            </View>

            <Text style={styles.label}>Klavuz Adı:</Text>
            <TextInput
                placeholder="Klavuz Adı"
                style={styles.input}
                value={name}
                onChangeText={setName}
            />

            <Text style={styles.label}>Açıklama:</Text>
            <TextInput
                placeholder="Açıklama"
                style={styles.input}
                value={description}
                onChangeText={setDescription}
            />

            <Text style={styles.label}>Birim:</Text>
            <View style={styles.pickerContainer}>
                <Picker
                    selectedValue={unit}
                    onValueChange={(itemValue) => setUnit(itemValue)}
                    style={styles.picker}
                >
                    <Picker.Item label="Birim Seçin" value="" />
                    <Picker.Item label="mg/L" value="mg/L" />
                    <Picker.Item label="g/L" value="g/L" />
                </Picker>
            </View>

            <Text style={styles.label}>Klavuz Tipi:</Text>
            <View style={styles.pickerContainer}>
                <Picker
                    selectedValue={type}
                    onValueChange={(itemValue) => setType(itemValue)}
                    style={styles.picker}
                >
                    <Picker.Item label="Tip Seçin" value="" />
                    <Picker.Item label="Geometric ve SD" value="geometric" />
                    <Picker.Item label="Min ve Max" value="minMax" />
                </Picker>
            </View>

            <Button title="Güncelle" onPress={updateGuide} />
        </View>
    );
};

export default EditGuideScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        backgroundColor: '#f5f5f5',
    },
    headerRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 15,
    },
    icon: {
        marginRight: 8,
    },
    headerTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#333',
    },
    label: {
        fontSize: 14,
        fontWeight: '600',
        marginBottom: 5,
        color: '#333',
    },
    input: {
        borderWidth: 1,
        borderColor: '#ccc',
        padding: 10,
        marginBottom: 10,
        borderRadius: 6,
        backgroundColor: '#fff',
    },
    pickerContainer: {
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 6,
        marginBottom: 15,
        backgroundColor: '#fff',
        overflow: 'hidden',
    },
    picker: {
        width: '100%',
    },
});
