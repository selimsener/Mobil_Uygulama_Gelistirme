// screens/Doctor/PatientAddScreen.js
import React, { useState } from 'react';
import { View, Text, Alert, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import CustomInput from '../../components/CustomInput';
import CustomButton from '../../components/CustomButton';
import DatePickerInput from '../../components/DatePickerInput';
import { auth, db } from '../../firebase';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc, getDocs, collection, query, where } from 'firebase/firestore';
import { validateEmail, validatePassword, validateName, validateTC, validateDate } from '../../utils/validators';

const PatientAddScreen = ({ navigation }) => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [tc, setTc] = useState("");
    const [name, setName] = useState("");
    const [birthDate, setBirthDate] = useState(new Date());
    const [loading, setLoading] = useState(false);

    const handleAddPatient = async () => {
        // Input validation
        if (!validateEmail(email)) {
            Alert.alert("Hata", "Geçerli bir email giriniz.");
            return;
        }
        if (!validatePassword(password)) {
            Alert.alert("Hata", "Şifre en az 6 karakter olmalı.");
            return;
        }
        if (!validateName(name)) {
            Alert.alert("Hata", "İsim soyisim alanı boş olamaz.");
            return;
        }
        if (!validateTC(tc)) {
            Alert.alert("Hata", "TC kimlik numarası 11 haneli olmalı.");
            return;
        }
        if (!validateDate(birthDate)) {
            Alert.alert("Hata", "Lütfen geçerli bir doğum tarihi seçiniz.");
            return;
        }

        setLoading(true);

        try {
            // TC ve Email'in benzersizliğini kontrol et
            const usersRef = collection(db, 'users');

            const tcQuery = query(usersRef, where('tc', '==', tc));
            const emailQuery = query(usersRef, where('email', '==', email));

            const [tcSnap, emailSnap] = await Promise.all([
                getDocs(tcQuery),
                getDocs(emailQuery)
            ]);

            if (!tcSnap.empty) {
                Alert.alert("Hata", "Bu TC kimlik numarası zaten kullanılıyor.");
                setLoading(false);
                return;
            }

            if (!emailSnap.empty) {
                Alert.alert("Hata", "Bu email zaten kullanılıyor.");
                setLoading(false);
                return;
            }

            // Firebase Auth ile kullanıcı oluştur
            const userCredential = await createUserWithEmailAndPassword(auth, email, password);
            const user = userCredential.user;

            // Kullanıcı verilerini Firestore'a ekle
            const formattedBirthDate = birthDate.toISOString().split('T')[0]; // YYYY-MM-DD

            await setDoc(doc(db, 'users', user.uid), {
                name,
                email,
                tc,
                birthDate: formattedBirthDate,
                role: 'patient',
                searchName: name.toLowerCase(), // Arama kolaylığı için
                createdAt: new Date(),
            });

            Alert.alert("Başarılı", "Hasta başarıyla eklendi.");
            navigation.goBack();
        } catch (error) {
            console.error("Hasta ekleme hatası:", error);
            Alert.alert("Hata", "Hasta eklenirken bir sorun oluştu. Lütfen tekrar deneyin.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <ScrollView contentContainerStyle={styles.container}>
            <CustomInput
                label="Ad Soyad"
                placeholder="Ad Soyad"
                value={name}
                onChangeText={setName}
            />
            <DatePickerInput
                label="Doğum Tarihi"
                date={birthDate}
                setDate={setBirthDate}
            />
            <CustomInput
                label="TC"
                placeholder="TC Kimlik Numarası"
                value={tc}
                onChangeText={setTc}
                keyboardType="numeric"
            />
            <CustomInput
                label="Email"
                placeholder="Email"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
            />
            <CustomInput
                label="Şifre"
                placeholder="Şifre"
                secureTextEntry
                value={password}
                onChangeText={setPassword}
            />
            <CustomButton title={loading ? "Ekleniyor..." : "Ekle"} onPress={handleAddPatient} disabled={loading} />
            <TouchableOpacity onPress={() => navigation.goBack()}>
                <Text style={styles.link}>
                    Geri dön <Text style={styles.linkHighlight}>Hasta Yönetimi</Text>
                </Text>
            </TouchableOpacity>
        </ScrollView>
    );
};

export default PatientAddScreen;

const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        padding: 20,
        justifyContent: 'center',
        backgroundColor: '#fff',
    },

    link: {
        textAlign: 'center',
        marginTop: 15,
        fontSize: 14,
    },
    linkHighlight: {
        color: "#007BFF",
        fontWeight: "bold",
    },
});
