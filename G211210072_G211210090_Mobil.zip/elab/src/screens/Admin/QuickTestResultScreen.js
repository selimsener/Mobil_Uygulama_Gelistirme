import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    TextInput,
    StyleSheet,
    Alert,
    ScrollView,
    Platform,
    ActivityIndicator,
    TouchableOpacity,
} from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../../firebase';
import { calculateAgeInMonths } from '../../utils/ageCalculator';
import { isAgeInRange } from '../../utils/ageRangeEvaluator';

const TEST_NAMES = ['IgA', 'IgM', 'IgG', 'IgG1', 'IgG2', 'IgG3', 'IgG4'];

const QuickTestResultScreen = () => {
    const [birthDate, setBirthDate] = useState(null);
    const [showDatePicker, setShowDatePicker] = useState(false);

    // Tetkik değerleri (opsiyonel)
    const [testValues, setTestValues] = useState({});

    // Firestore'dan kılavuz verileri
    const [guides, setGuides] = useState([]);
    const [loading, setLoading] = useState(false);

    // Sonuçlar
    const [results, setResults] = useState([]);

    // Yaşı ay cinsinden tutmak
    const [ageInMonths, setAgeInMonths] = useState(null);

    // Sayfa yüklenince kılavuzları çek
    useEffect(() => {
        const fetchGuides = async () => {
            try {
                setLoading(true);
                const guidesSnap = await getDocs(collection(db, 'guides'));
                const guidesData = guidesSnap.docs.map(doc => ({
                    id: doc.id,
                    ...doc.data(),
                }));
                setGuides(guidesData);
            } catch (error) {
                console.error('Kılavuz bilgileri alınırken hata:', error);
                Alert.alert('Hata', 'Kılavuz bilgileri alınamadı.');
            } finally {
                setLoading(false);
            }
        };
        fetchGuides();
    }, []);

    // Tarih seçici
    const onChangeDate = (event, selectedDate) => {
        setShowDatePicker(false);
        if (event.type === 'set' && selectedDate) {
            setBirthDate(selectedDate);
            // Yaş ay cinsinden hesapla ve kaydet
            const months = calculateAgeInMonths(selectedDate.toISOString());
            setAgeInMonths(months);
        }
    };

    // Birim dönüşümü (g/L <-> mg/L)
    const convertUnits = (value, fromUnit, toUnit) => {
        if (fromUnit === toUnit) return value;
        if (fromUnit === 'g/L' && toUnit === 'mg/L') return value * 1000;
        if (fromUnit === 'mg/L' && toUnit === 'g/L') return value / 1000;
        return value;
    };

    // "Sorgula" butonu
    const handleCalculate = async () => {
        if (!birthDate) {
            Alert.alert('Uyarı', 'Lütfen doğum tarihi seçiniz.');
            return;
        }
        setLoading(true);

        // Yaş ay cinsinden tekrar hesap (tekrar lazımsa)
        const months = calculateAgeInMonths(birthDate.toISOString());
        setAgeInMonths(months);

        const finalResults = TEST_NAMES.map(testName => {
            const inputVal = parseFloat(testValues[testName]);
            if (isNaN(inputVal)) return null;

            const evaluations = [];
            guides.forEach(guide => {
                guide.testTypes.forEach(testType => {
                    if (testType.name === testName) {
                        const ageGroup = testType.ageGroups.find(ag =>
                            isAgeInRange(months, ag.ageRange)
                        );
                        if (ageGroup) {
                            const convertedVal = convertUnits(
                                inputVal,
                                'g/L',
                                guide.unit || 'mg/L'
                            );
                            const { referenceMin, referenceMax } = ageGroup;
                            let status = 'Normal';
                            if (convertedVal < referenceMin) status = 'Düşük';
                            else if (convertedVal > referenceMax) status = 'Yüksek';

                            evaluations.push({
                                guideName: guide.name || 'Bilinmeyen Kılavuz',
                                referenceMin: referenceMin.toFixed(2),
                                referenceMax: referenceMax.toFixed(2),
                                status,
                                unit: guide.unit || 'mg/L',
                            });
                        }
                    }
                });
            });

            return {
                testName,
                inputValue: inputVal.toFixed(2),
                inputValueMgL: convertUnits(inputVal, 'g/L', 'mg/L').toFixed(2),
                evaluations,
            };
        }).filter(Boolean);

        // Bunu biraz gecikmeli göstermek isterseniz test amaçlı bir setTimeout kullanabilirsiniz
        // setTimeout(() => { setResults(finalResults); setLoading(false); }, 1000);
        setResults(finalResults);
        setLoading(false);
    };

    // "Tüm Değerleri Sil" butonu
    const handleClearAll = () => {
        setTestValues({});
        setResults([]);
    };

    // Duruma göre renk & ikon
    const getStatusStyle = status => {
        switch (status) {
            case 'Normal':
                return { color: '#4CAF50', icon: 'checkmark-circle' };
            case 'Düşük':
                return { color: '#FF9800', icon: 'arrow-down-circle' };
            case 'Yüksek':
                return { color: '#F44336', icon: 'arrow-up-circle' };
            default:
                return { color: '#555', icon: 'ellipse' };
        }
    };

    return (
        <ScrollView contentContainerStyle={styles.container}>
            <Text style={styles.title}>Hızlı Tahlil Sorgulama</Text>

            {/* Doğum Tarihi */}
            <Text style={styles.label}>Doğum Tarihi</Text>
            <TouchableOpacity
                style={styles.iconButton}
                onPress={() => setShowDatePicker(true)}
            >
                <Ionicons
                    name="calendar"
                    size={20}
                    color="#fff"
                    style={{ marginRight: 5 }}
                />
                <Text style={styles.iconButtonText}>
                    {birthDate ? birthDate.toLocaleDateString() : 'Seçiniz'}
                </Text>
            </TouchableOpacity>

            {showDatePicker && (
                <DateTimePicker
                    value={birthDate || new Date()}
                    mode="date"
                    display={Platform.OS === 'ios' ? 'inline' : 'default'}
                    onChange={onChangeDate}
                    maximumDate={new Date()}
                />
            )}

            {/* Yaş (Ay) gösterimi */}
            {ageInMonths !== null && (
                <Text style={styles.ageText}>Yaş (Ay): {ageInMonths}</Text>
            )}

            {/* Test Değerleri */}
            <Text style={styles.label}>Test Değerleri (g/L)</Text>
            {TEST_NAMES.map((testName) => (
                <View key={testName} style={styles.testRow}>
                    <Text style={styles.testName}>{testName}:</Text>
                    <TextInput
                        placeholder={`Örn. ${testName} değeri`}
                        value={testValues[testName] || ''}
                        onChangeText={(val) =>
                            setTestValues({ ...testValues, [testName]: val })
                        }
                        keyboardType="numeric"
                        style={styles.input}
                    />
                </View>
            ))}

            {/* Butonlar (Sorgula & Tüm Değerleri Sil) */}
            <View style={styles.buttonRow}>
                <TouchableOpacity
                    style={[
                        styles.searchButton,
                        loading && styles.searchButtonDisabled,
                    ]}
                    onPress={handleCalculate}
                    disabled={loading}
                >
                    {loading ? (
                        <>
                            <ActivityIndicator size="small" color="#fff" style={{ marginRight: 5 }} />
                            <Text style={styles.searchButtonText}>Sorgulanıyor...</Text>
                        </>
                    ) : (
                        <>
                            <Ionicons
                                name="search"
                                size={20}
                                color="#fff"
                                style={{ marginRight: 5 }}
                            />
                            <Text style={styles.searchButtonText}>Sorgula</Text>
                        </>
                    )}
                </TouchableOpacity>

                <TouchableOpacity
                    style={styles.clearButton}
                    onPress={handleClearAll}
                >
                    <Ionicons
                        name="trash"
                        size={20}
                        color="#fff"
                        style={{ marginRight: 5 }}
                    />
                    <Text style={styles.clearButtonText}>Tüm Değerleri Sil</Text>
                </TouchableOpacity>
            </View>

            {/* Sonuçlar */}
            {results.length > 0 && (
                <View style={{ marginTop: 30 }}>
                    <Text style={styles.resultTitle}>Sonuçlar</Text>
                    {results.map((res, index) => (
                        <View key={index} style={styles.resultBlock}>
                            <View style={styles.resultHeader}>
                                <Ionicons
                                    name="flask"
                                    size={18}
                                    color="#333"
                                    style={{ marginRight: 5 }}
                                />
                                <Text style={styles.resultTestName}>
                                    {res.testName}: {res.inputValue} g/L {res.inputValueMgL} mg/L
                                </Text>
                            </View>

                            {res.evaluations.length === 0 ? (
                                <Text style={styles.resultNoGuide}>
                                    Uygun bir kılavuz aralığı bulunamadı.
                                </Text>
                            ) : (
                                res.evaluations.map((evalItem, i) => {
                                    const { color, icon } = getStatusStyle(evalItem.status);
                                    return (
                                        <View key={i} style={styles.evalRow}>
                                            {/* Durum */}
                                            <View style={styles.statusRow}>
                                                <Ionicons
                                                    name={icon}
                                                    size={16}
                                                    color={color}
                                                    style={{ marginRight: 5 }}
                                                />
                                                <Text style={[styles.evalStatus, { color }]}>
                                                    {evalItem.status}
                                                </Text>
                                            </View>
                                            {/* Detaylar */}
                                            <View style={styles.evalDetailsContainer}>
                                                <Text style={styles.evalDetails}>
                                                    {evalItem.guideName}
                                                </Text>
                                                <Text style={styles.evalDetails}>
                                                    Referans Aralık: {evalItem.referenceMin} -{' '}
                                                    {evalItem.referenceMax} {evalItem.unit}
                                                </Text>
                                            </View>
                                        </View>
                                    );
                                })
                            )}
                        </View>
                    ))}
                </View>
            )}
        </ScrollView>
    );
};

export default QuickTestResultScreen;

const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        paddingHorizontal: 16,
        paddingTop: 20,
        paddingBottom: 40,
        backgroundColor: '#f9f9f9',
    },
    title: {
        fontSize: 22,
        fontWeight: 'bold',
        marginBottom: 20,
        textAlign: 'center',
        color: '#333',
    },
    label: {
        fontSize: 15,
        fontWeight: '600',
        marginBottom: 8,
        color: '#555',
    },
    iconButton: {
        flexDirection: 'row',
        backgroundColor: '#4CAF50',
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 10,
        borderRadius: 5,
        marginBottom: 15,
    },
    iconButtonText: {
        color: '#fff',
        fontSize: 15,
        flexShrink: 1,
    },
    ageText: {
        fontSize: 16,
        fontWeight: 'bold',
        marginBottom: 15,
        color: '#333',
        textAlign: 'center',
    },
    testRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 12,
    },
    testName: {
        width: 80,
        fontWeight: 'bold',
        color: '#333',
    },
    input: {
        borderWidth: 1,
        borderColor: '#ccc',
        flex: 1,
        padding: 8,
        borderRadius: 5,
        backgroundColor: '#fff',
    },
    buttonRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: 10,
    },
    searchButton: {
        flexDirection: 'row',
        backgroundColor: '#2196F3',
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 12,
        borderRadius: 5,
        flex: 0.48,
    },
    searchButtonDisabled: {
        backgroundColor: '#a0c4ff', // Yükleniyorsa buton rengini açık mavi yap
    },
    searchButtonText: {
        color: '#fff',
        fontSize: 15,
        fontWeight: '600',
    },
    clearButton: {
        flexDirection: 'row',
        backgroundColor: '#f44336',
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 12,
        borderRadius: 5,
        flex: 0.48,
    },
    clearButtonText: {
        color: '#fff',
        fontSize: 15,
        fontWeight: '600',
    },
    resultTitle: {
        fontSize: 18,
        fontWeight: '700',
        marginBottom: 10,
        color: '#444',
        textAlign: 'center',
    },
    resultBlock: {
        backgroundColor: '#fff',
        borderRadius: 5,
        padding: 10,
        marginBottom: 15,
        borderWidth: 1,
        borderColor: '#ddd',
    },
    resultHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 5,
    },
    resultTestName: {
        fontWeight: '700',
        fontSize: 15,
        color: '#333',
        flexShrink: 1,
        flexWrap: 'wrap',
    },
    resultNoGuide: {
        fontStyle: 'italic',
        color: '#777',
        paddingTop: 4,
        paddingLeft: 4,
    },
    evalRow: {
        flexDirection: 'column',
        alignItems: 'flex-start',
        marginLeft: 10,
        marginTop: 4,
    },
    statusRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 2,
    },
    evalStatus: {
        fontSize: 14,
        fontWeight: '600',
    },
    evalDetailsContainer: {
        marginLeft: 0,
    },
    evalDetails: {
        fontSize: 12,
        color: '#555',
        marginBottom: 2,
        lineHeight: 18,
    },
    guideName: {
        fontWeight: '600',
        color: '#333',
    },
});
