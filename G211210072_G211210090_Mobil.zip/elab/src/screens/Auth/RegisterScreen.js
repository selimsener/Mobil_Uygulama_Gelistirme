// screens/Auth/RegisterScreen.js
import React, { useState, useContext } from 'react';
import { 
    View, 
    Text, 
    Alert, 
    StyleSheet, 
    TouchableOpacity, 
    KeyboardAvoidingView, 
    Platform, 
    ScrollView 
} from 'react-native';
import CustomInput from '../../components/CustomInput';
import CustomButton from '../../components/CustomButton';
import DatePickerInput from '../../components/DatePickerInput';
import { registerUser } from '../../services/authService';
import { AuthContext } from '../../contexts/AuthContext';
import { validateEmail, validatePassword, validateName, validateTC, validateDate } from '../../utils/validators';

const RegisterScreen = ({ navigation }) => {
    const { setUser } = useContext(AuthContext);

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [tc, setTc] = useState("");
    const [name, setName] = useState("");
    const [birthDate, setBirthDate] = useState(new Date());

    const handleRegister = async () => {
        // Input validation
        if (!validateEmail(email)) {
            Alert.alert("Hata", "Geçerli bir email giriniz.");
            return;
        }
        if (!validatePassword(password)) {
            Alert.alert("Hata", "Şifre en az 6 karakter olmalı.");
            return;
        }
        if (!validateName(name)) {
            Alert.alert("Hata", "İsim soyisim alanı boş olamaz.");
            return;
        }
        if (!validateTC(tc)) {
            Alert.alert("Hata", "TC kimlik numarası 11 haneli olmalı.");
            return;
        }
        if (!validateDate(birthDate)) {
            Alert.alert("Hata", "Lütfen geçerli bir doğum tarihi seçiniz.");
            return;
        }

        try {
            // Prepare data for registration
            const formattedBirthDate = birthDate.toISOString().split('T')[0]; // Convert to YYYY-MM-DD
            const userData = await registerUser({
                email,
                password,
                name,
                birthDate: formattedBirthDate,
                tc,
            });

            setUser(userData); // Set user context
            Alert.alert("Başarılı", "Kayıt başarılı! Giriş yapabilirsiniz.");
            navigation.navigate("Login"); // Redirect to Login screen
        } catch (error) {
            console.error("Register Error:", error);
            Alert.alert("Hata", "Kayıt sırasında bir sorun oluştu. Lütfen tekrar deneyin.");
        }
    };

    return (
        <KeyboardAvoidingView
            style={styles.keyboardAvoidingView}
            behavior={Platform.OS === "ios" ? "padding" : "height"}
            keyboardVerticalOffset={Platform.OS === "ios" ? 0 : 20} // Adjust if you have a header
        >
            <ScrollView 
                contentContainerStyle={styles.scrollViewContent}
                keyboardShouldPersistTaps="handled"
            >
                <View style={styles.container}>
                    <Text style={styles.title}>Kayıt Ol</Text>
                    <CustomInput
                        label="Ad Soyad"
                        placeholder="Ad Soyad"
                        value={name}
                        onChangeText={setName}
                    />
                    <DatePickerInput
                        label="Doğum Tarihi"
                        date={birthDate}
                        setDate={setBirthDate}
                    />
                    <CustomInput
                        label="TC"
                        placeholder="TC Kimlik Numarası"
                        value={tc}
                        onChangeText={setTc}
                        keyboardType="numeric"
                    />
                    <CustomInput
                        label="Email"
                        placeholder="Email"
                        value={email}
                        onChangeText={setEmail}
                        keyboardType="email-address"
                    />
                    <CustomInput
                        label="Şifre"
                        placeholder="Şifre"
                        secureTextEntry
                        value={password}
                        onChangeText={setPassword}
                    />
                    <CustomButton title="Kayıt" onPress={handleRegister} />
                    <TouchableOpacity onPress={() => navigation.navigate("Login")}>
                        <Text style={styles.link}>
                            Zaten bir hesabınız var mı? <Text style={styles.linkHighlight}>Giriş Yap</Text>
                        </Text>
                    </TouchableOpacity>
                </View>
            </ScrollView>
        </KeyboardAvoidingView>
    );
};

export default RegisterScreen;

const styles = StyleSheet.create({
    keyboardAvoidingView: {
        flex: 1,
    },
    scrollViewContent: {
        flexGrow: 1,
        justifyContent: 'center',
        padding: 20,
    },
    container: {
        // Removed flex: 1 to prevent conflicts with ScrollView and KeyboardAvoidingView
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 20,
        textAlign: 'center',
    },
    link: {
        textAlign: 'center',
        marginTop: 15,
        fontSize: 14,
    },
    linkHighlight: {
        color: "#007BFF",
        fontWeight: "bold",
    },
});