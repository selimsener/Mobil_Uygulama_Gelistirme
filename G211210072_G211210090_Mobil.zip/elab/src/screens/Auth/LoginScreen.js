// screens/Auth/LoginScreen.js
import React, { useState, useContext } from 'react';
import { View, Text, Alert, StyleSheet, TouchableOpacity } from 'react-native';
import CustomInput from '../../components/CustomInput';
import CustomButton from '../../components/CustomButton';
import { loginUser } from '../../services/authService';
import { AuthContext } from '../../contexts/AuthContext';
import { validateEmail, validatePassword } from '../../utils/validators';

const LoginScreen = ({ navigation }) => {
    const { setUser } = useContext(AuthContext);
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const handleLogin = async () => {
        if (!validateEmail(email)) {
            Alert.alert("Hata", "Lütfen geçerli bir email giriniz.");
            return;
        }
        if (!validatePassword(password)) {
            Alert.alert("Hata", "Şifre en az 6 karakter olmalı.");
            return;
        }
        try {
            const userData = await loginUser(email, password);
            setUser(userData);
        } catch (error) {
            Alert.alert("Hata ! email veya şifre hatalı");
        }
    };

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Giriş Yap</Text>
            <CustomInput
                label="Email"
                placeholder="Email"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
            />
            <CustomInput
                label="Şifre"
                placeholder="Şifre"
                secureTextEntry
                value={password}
                onChangeText={setPassword}
            />
            <CustomButton title="Giriş" onPress={handleLogin} />
            <TouchableOpacity onPress={() => navigation.navigate("Register")}>
                <Text style={styles.link}>
                    Hesabınız yok mu? <Text style={styles.linkHighlight}>Kayıt Ol</Text>
                </Text>
            </TouchableOpacity>
        </View>
    );
};

export default LoginScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        justifyContent: 'center',
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 20,
        textAlign: 'center',
    },
    link: {
        textAlign: 'center',
        marginTop: 15,
        fontSize: 14,
    },
    linkHighlight: {
        color: "#007BFF",
        fontWeight: "bold",
    },
});
// Compare this snippet from src/screens/Auth/RegisterScreen.js:
