// ./src/screens/Patient/UserProfile.js

import React, { useEffect, useState, useContext } from 'react';
import {
    View,
    Text,
    TextInput,
    StyleSheet,
    Button,
    Alert,
    ActivityIndicator,
    ScrollView,
    TouchableOpacity,
    Platform,
} from 'react-native';
import { auth, db } from '../../firebase';
import {
    updateDoc,
    doc,
    getDoc,
    deleteDoc,
} from 'firebase/firestore';
import { AuthContext } from '../../contexts/AuthContext'; // AuthContext'i içe aktarın
import { validateEmail, validateName, validateTC, validateDate } from '../../utils/validators';
import DatePickerInput from '../../components/DatePickerInput'; // DatePickerInput'i içe aktarın

const UserProfile = ({ navigation }) => {
    const { user: contextUser, updateUser } = useContext(AuthContext); // AuthContext'ten user ve updateUser'ı alın
    const [loading, setLoading] = useState(true);
    const [editing, setEditing] = useState(false);
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        birthDate: '',
        tc: '',
    });
    const [errors, setErrors] = useState({});

    useEffect(() => {
        const fetchUserData = async () => {
            try {
                const currentUser = auth.currentUser;
                if (currentUser) {
                    const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
                    if (userDoc.exists()) {
                        const userData = userDoc.data();
                        setFormData({
                            name: userData.name,
                            email: userData.email,
                            birthDate: userData.birthDate ? new Date(userData.birthDate) : '',
                            tc: userData.tc,
                        });
                    }
                }
            } catch (error) {
                Alert.alert('Hata', 'Kullanıcı verileri alınırken bir hata oluştu.');
            } finally {
                setLoading(false);
            }
        };

        fetchUserData();
    }, []);

    const handleChange = (field, value) => {
        setFormData({ ...formData, [field]: value });
    };

    const validate = () => {
        const newErrors = {};
        if (!validateName(formData.name)) newErrors.name = 'Geçerli bir isim girin.';
        if (!validateEmail(formData.email)) newErrors.email = 'Geçerli bir e-posta girin.';
        if (!validateDate(formData.birthDate)) newErrors.birthDate = 'Geçerli bir doğum tarihi girin.';
        if (!validateTC(formData.tc)) newErrors.tc = 'Geçerli bir TC kimlik numarası girin.';
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleUpdate = async () => {
        if (!validate()) {
            return;
        }

        try {
            const currentUser = auth.currentUser;
            if (currentUser) {
                await updateDoc(doc(db, 'users', currentUser.uid), {
                    name: formData.name,
                    email: formData.email,
                    birthDate: formData.birthDate.toISOString(),
                    tc: formData.tc,
                });
                Alert.alert('Başarılı', 'Profiliniz güncellendi.');
                setEditing(false);
                // AuthContext'teki kullanıcı bilgilerini güncelleyin
                updateUser({
                    ...contextUser,
                    name: formData.name,
                    email: formData.email,
                    birthDate: formData.birthDate,
                    tc: formData.tc,
                });
            }
        } catch (error) {
            Alert.alert('Hata', 'Profil güncellenirken bir hata oluştu.');
        }
    };

    const handleDeleteAccount = () => {
        Alert.alert(
            'Hesabı Sil',
            'Hesabınızı silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.',
            [
                { text: 'İptal', style: 'cancel' },
                { text: 'Sil', style: 'destructive', onPress: confirmDeleteAccount },
            ]
        );
    };

    const confirmDeleteAccount = async () => {
        try {
            const currentUser = auth.currentUser;
            if (currentUser) {
                // Firestore'dan kullanıcı verilerini sil
                await deleteDoc(doc(db, 'users', currentUser.uid));

                // Firebase Authentication'dan kullanıcıyı sil
                await currentUser.delete();

                Alert.alert('Hesap Silindi', 'Hesabınız başarıyla silindi.');
                // Giriş ekranına yönlendirme veya uygulamayı kapatma
                navigation.reset({
                    index: 0,
                    routes: [{ name: 'Login' }],
                });
            }
        } catch (error) {
            if (error.code === 'auth/requires-recent-login') {
                Alert.alert(
                    'Hata',
                    'Hesabınızı silmek için lütfen tekrar giriş yapın.',
                    [
                        { text: 'Tamam', onPress: () => navigation.navigate('Login') },
                    ]
                );
            } else {
                Alert.alert('Hata', 'Hesap silinirken bir hata oluştu. Lütfen tekrar deneyin.');
            }
        }
    };

    if (loading) {
        return (
            <View style={styles.loadingContainer}>
                <ActivityIndicator size="large" color="#4a90e2" />
            </View>
        );
    }

    return (
        <ScrollView contentContainerStyle={styles.container}>


            <View style={styles.fieldContainer}>
                <Text style={styles.label}>Ad Soyad</Text>
                {editing ? (
                    <TextInput
                        style={[styles.input, errors.name && styles.inputError]}
                        value={formData.name}
                        onChangeText={(text) => handleChange('name', text)}
                        placeholder="Adınızı girin"
                    />
                ) : (
                    <Text style={styles.value}>{formData.name}</Text>
                )}
                {errors.name && <Text style={styles.error}>{errors.name}</Text>}
            </View>

            <View style={styles.fieldContainer}>
                <Text style={styles.label}>E-posta</Text>
                {editing ? (
                    <TextInput
                        style={[styles.input, errors.email && styles.inputError]}
                        value={formData.email}
                        onChangeText={(text) => handleChange('email', text)}
                        keyboardType="email-address"
                        autoCapitalize="none"
                        placeholder="E-posta adresinizi girin"
                    />
                ) : (
                    <Text style={styles.value}>{formData.email}</Text>
                )}
                {errors.email && <Text style={styles.error}>{errors.email}</Text>}
            </View>

            <View style={styles.fieldContainer}>
                <Text style={styles.label}>Doğum Tarihi</Text>
                {editing ? (
                    <DatePickerInput
                        label="Doğum Tarihi"
                        date={formData.birthDate}
                        setDate={(date) => handleChange('birthDate', date)}
                    />
                ) : (
                    <Text style={styles.value}>
                        {formData.birthDate
                            ? formData.birthDate.toLocaleDateString()
                            : ''}
                    </Text>
                )}
                {errors.birthDate && <Text style={styles.error}>{errors.birthDate}</Text>}
            </View>

            <View style={styles.fieldContainer}>
                <Text style={styles.label}>TC Kimlik No</Text>
                {editing ? (
                    <TextInput
                        style={[styles.input, errors.tc && styles.inputError]}
                        value={formData.tc}
                        onChangeText={(text) => handleChange('tc', text)}
                        keyboardType="numeric"
                        maxLength={11}
                        placeholder="TC Kimlik Numaranızı girin"
                    />
                ) : (
                    <Text style={styles.value}>{formData.tc}</Text>
                )}
                {errors.tc && <Text style={styles.error}>{errors.tc}</Text>}
            </View>

            {editing ? (
                <View style={styles.buttonContainer}>
                    <TouchableOpacity style={styles.updateButton} onPress={handleUpdate}>
                        <Text style={styles.buttonText}>Güncelle</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.cancelButton} onPress={() => setEditing(false)}>
                        <Text style={styles.buttonText}>İptal</Text>
                    </TouchableOpacity>
                </View>
            ) : (
                <View style={styles.buttonContainer}>
                    <TouchableOpacity style={styles.editButton} onPress={() => setEditing(true)}>
                        <Text style={styles.buttonText}>Düzenle</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={styles.changePasswordButton}
                        onPress={() => navigation.navigate('ChangePassword')}
                    >
                        <Text style={styles.buttonText}>Şifre Değiştir</Text>
                    </TouchableOpacity>
                </View>
            )}

            <View style={styles.deleteButtonContainer}>
                <TouchableOpacity style={styles.deleteButton} onPress={handleDeleteAccount}>
                    <Text style={styles.deleteButtonText}>Hesabı Sil</Text>
                </TouchableOpacity>
            </View>
        </ScrollView>
    );

};

const styles = StyleSheet.create({
    container: {
        padding: 20,
        backgroundColor: '#f5f5f5',
        flexGrow: 1,
    },
    loadingContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    fieldContainer: {
        marginBottom: 20,
    },
    label: {
        fontSize: 16,
        marginBottom: 8,
        color: '#333',
        fontWeight: '600',
    },
    input: {
        borderWidth: 1,
        borderColor: '#ccc',
        padding: 12,
        borderRadius: 8,
        backgroundColor: '#fff',
        fontSize: 16,
    },
    inputError: {
        borderColor: 'red',
    },
    value: {
        fontSize: 16,
        padding: 12,
        backgroundColor: '#fff',
        borderRadius: 8,
        color: '#555',
    },
    error: {
        color: 'red',
        marginTop: 5,
        fontSize: 14,
    },
    buttonContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: 10,
    },
    editButton: {
        flex: 1,
        backgroundColor: '#4a90e2',
        padding: 15,
        borderRadius: 8,
        marginRight: 10,
        alignItems: 'center',
    },
    changePasswordButton: {
        flex: 1,
        backgroundColor: '#50C878',
        padding: 15,
        borderRadius: 8,
        marginLeft: 10,
        alignItems: 'center',
    },
    updateButton: {
        flex: 1,
        backgroundColor: '#28a745',
        padding: 15,
        borderRadius: 8,
        marginRight: 10,
        alignItems: 'center',
    },
    cancelButton: {
        flex: 1,
        backgroundColor: '#6c757d',
        padding: 15,
        borderRadius: 8,
        marginLeft: 10,
        alignItems: 'center',
    },
    buttonText: {
        color: '#fff',
        fontSize: 16,
        fontWeight: '600',
    },
    deleteButtonContainer: {
        marginTop: 40,
        alignItems: 'center',
    },
    deleteButton: {
        backgroundColor: '#dc3545',
        paddingVertical: 15,
        paddingHorizontal: 30,
        borderRadius: 8,
    },
    deleteButtonText: {
        color: '#fff',
        fontSize: 16,
        fontWeight: '600',
    },
});

export default UserProfile;
