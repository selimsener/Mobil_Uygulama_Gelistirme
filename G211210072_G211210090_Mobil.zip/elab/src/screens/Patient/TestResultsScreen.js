// screens/Patient/TestResultsScreen.js
import React, { useEffect, useState, useCallback } from 'react';
import {
    View,
    Text,
    FlatList,
    TouchableOpacity,
    StyleSheet,
    ActivityIndicator,
    Platform,
} from 'react-native';
import { getDocs, collection, query as firestoreQuery, orderBy } from 'firebase/firestore';
import { auth, db } from '../../firebase';
import { useNavigation } from '@react-navigation/native';
import { Searchbar } from 'react-native-paper';
import debounce from 'lodash.debounce';
import Ionicons from 'react-native-vector-icons/Ionicons';

// mg/L dönüşümü fonksiyonu
const convertToMgL = (valueInGL) => valueInGL * 1000;

// Durum ikonları
const getStatusIcon = (status) => {
    switch (status) {
        case 'Yüksek':
            return 'arrow-up-circle';
        case 'Normal':
            return 'checkmark-circle';
        case 'Düşük':
            return 'arrow-down-circle';
        default:
            return 'help-circle';
    }
};

// Durum renkleri
const getStatusColor = (status) => {
    switch (status) {
        case 'Yüksek':
            return 'red';
        case 'Normal':
            return 'green';
        case 'Düşük':
            return 'orange';
        default:
            return 'grey';
    }
};

const TestResultsScreen = () => {
    const [testResults, setTestResults] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');

    const userId = auth.currentUser?.uid;
    const navigation = useNavigation();

    // 500 ms gecikmeli arama (debounce)
    const debouncedSearch = useCallback(
        debounce((queryParam) => {
            fetchTestResults(queryParam);
        }, 500),
        []
    );

    useEffect(() => {
        fetchTestResults();
    }, []);

    const fetchTestResults = async (searchParam = searchQuery) => {
        if (!userId) return;
        setLoading(true);
        try {
            const q = firestoreQuery(
                collection(db, 'users', userId, 'results'),
                orderBy('date', 'desc')
            );
            const querySnapshot = await getDocs(q);
            let results = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

            if (searchParam) {
                const lowercasedQuery = searchParam.toLowerCase();
                results = results.filter(result => {
                    const matchesDate = result.date
                        .toDate()
                        .toLocaleDateString()
                        .toLowerCase()
                        .includes(lowercasedQuery);
                    const matchesTestName = result.tests.some(test =>
                        test.name.toLowerCase().includes(lowercasedQuery)
                    );
                    return matchesDate || matchesTestName;
                });
            }

            setTestResults(results);
        } catch (error) {
            console.error('Fetch Test Results Error:', error);
            alert('Veriler alınamadı: ' + error.message);
        } finally {
            setLoading(false);
        }
    };

    const handleSearchChange = (query) => {
        setSearchQuery(query);
        debouncedSearch(query);
    };

    // Liste öğesi render
    const renderTestItem = ({ item }) => (
        <View style={styles.cardContainer}>
            {/* Tahlil Tarihi (Header) */}
            <View style={styles.dateHeader}>
                <Text style={styles.dateHeaderText}>
                    Tahlil Tarihi: {item.date.toDate().toLocaleString()}
                </Text>
            </View>

            {/* Her test için küçük bir kart */}
            {item.tests.map((test, index) => {
                const gLValue = parseFloat(test.value) || 0;
                const mgLValue = convertToMgL(gLValue);

                return (
                    <View key={index} style={styles.testBlock}>
                        {/* Tetkik Adı ve Değeri */}
                        <View style={styles.testBlockHeader}>
                            <Ionicons
                                name="flask-outline"
                                size={16}
                                color="#555"
                                style={styles.testIcon}
                            />
                            <Text style={styles.testTitle}>
                                {test.name}  {gLValue.toFixed(2)} g/L  ({mgLValue.toFixed(2)} mg/L)
                            </Text>
                        </View>

                        {/* Her klavuz değerlendirmesi */}
                        {test.evaluations.map((evalItem, idx) => {
                            return (
                                <View key={idx} style={styles.evalRow}>
                                    {/* Durum ikonu + metin */}
                                    <View style={styles.statusRow}>
                                        <Ionicons
                                            name={getStatusIcon(evalItem.status)}
                                            size={16}
                                            color={getStatusColor(evalItem.status)}
                                            style={styles.statusIcon}
                                        />
                                        <Text
                                            style={[
                                                styles.status,
                                                { color: getStatusColor(evalItem.status) },
                                            ]}
                                        >
                                            {evalItem.status}
                                        </Text>
                                    </View>

                                    {/* Klavuz ismi */}
                                    <Text style={styles.guideLabel}>
                                        Klavuz İsmi: <Text style={styles.guideValue}>{evalItem.guideName}</Text>
                                    </Text>

                                    {/* Referans Aralıkları */}
                                    <Text style={styles.referenceLabel}>
                                        Referans Aralıkları:{' '}
                                        <Text style={styles.referenceValue}>
                                            {evalItem.referenceMin.toFixed(2)} - {evalItem.referenceMax.toFixed(2)} {evalItem.unit}
                                        </Text>
                                    </Text>
                                </View>
                            );
                        })}
                    </View>
                );
            })}

            {/* Detaya Git Butonu */}
            <TouchableOpacity
                style={styles.detailButton}
                onPress={() => navigation.navigate('TestDetail', { testId: item.id })}
            >
                <Text style={styles.detailButtonText}>Detaya Git</Text>
                <Ionicons
                    name="arrow-forward-circle-outline"
                    size={20}
                    color="#4a90e2"
                    style={styles.detailIcon}
                />
            </TouchableOpacity>
        </View>
    );

    return (
        <View style={styles.container}>
            <Searchbar
                placeholder="Ara..."
                onChangeText={handleSearchChange}
                value={searchQuery}
                style={styles.searchBar}
                inputStyle={styles.searchInput}
                placeholderTextColor="#888"
                iconColor="#555"
                clearIconColor="#555"
                returnKeyType="search"
                autoCorrect={false}
                autoCapitalize="none"
            />

            {loading ? (
                <ActivityIndicator size="large" color="#007BFF" style={styles.loader} />
            ) : (
                <FlatList
                    data={testResults}
                    keyExtractor={item => item.id}
                    renderItem={renderTestItem}
                    contentContainerStyle={styles.listContent}
                    ListEmptyComponent={
                        <Text style={styles.emptyText}>
                            Hiç tahlil sonucu bulunmamaktadır.
                        </Text>
                    }
                />
            )}
        </View>
    );
};

export default TestResultsScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f5f5f5',
        padding: 10,
    },
    loader: {
        flex: 1,
        justifyContent: 'center',
        marginTop: 20,
    },
    searchBar: {
        marginBottom: 10,
        backgroundColor: '#e0e0e0', // Daha yumuşak bir gri renk
        borderRadius: 8,
        elevation: 0, // Gölge kaldırıldı
        // height: 40, // Yüksekliği kaldırdık
        paddingVertical: Platform.OS === 'ios' ? 8 : 0, // iOS için padding
    },
    searchInput: {
        color: '#333', // Metin rengi
        // Dikey ortalama için ayarlar
        ...Platform.select({
            ios: {
                lineHeight: 20,
            },
            android: {
                textAlignVertical: 'center',
                lineHeight: 20,
            },
        }),
    },
    listContent: {
        paddingBottom: 50,
    },
    emptyText: {
        textAlign: 'center',
        marginTop: 20,
        color: '#888',
        fontSize: 15,
    },
    cardContainer: {
        backgroundColor: '#fff',
        borderRadius: 8,
        marginBottom: 15,
        elevation: 2,
    },
    dateHeader: {
        backgroundColor: '#4a90e2',
        borderTopLeftRadius: 8,
        borderTopRightRadius: 8,
        paddingHorizontal: 10,
        paddingVertical: 8,
    },
    dateHeaderText: {
        fontSize: 14,
        fontWeight: '700',
        color: '#fff',
    },
    testBlock: {
        padding: 10,
        borderBottomWidth: 1,
        borderColor: '#ddd',
    },
    testBlockHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 6,
    },
    testIcon: {
        marginRight: 6,
    },
    testTitle: {
        fontSize: 14,
        fontWeight: '600',
        color: '#333',
        flex: 1,
    },
    evalRow: {
        backgroundColor: '#f9f9f9',
        borderRadius: 6,
        padding: 8,
        marginBottom: 6,
    },
    statusRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 4,
    },
    statusIcon: {
        marginRight: 4,
    },
    status: {
        fontSize: 14,
        fontWeight: '600',
    },
    guideLabel: {
        fontSize: 14,
        fontWeight: '600',
        marginTop: 4,
        color: '#333',
    },
    guideValue: {
        fontWeight: '400',
        color: '#666',
    },
    referenceLabel: {
        fontSize: 14,
        fontWeight: '600',
        marginTop: 4,
        color: '#333',
    },
    referenceValue: {
        fontWeight: '400',
        color: '#666',
    },
    detailButton: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-end',
        padding: 10,
        borderTopWidth: 1,
        borderColor: '#ddd',
    },
    detailButtonText: {
        color: '#4a90e2',
        fontSize: 16,
        fontWeight: '600',
        marginRight: 5,
    },
    detailIcon: {
        marginRight: 5,
    },
});
