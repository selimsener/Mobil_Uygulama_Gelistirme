// ./src/screens/Patient/PatientDashboard.js

import React, { useContext, useState, useRef } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    SafeAreaView,
    ScrollView,
    Animated,
    Dimensions,
    TouchableWithoutFeedback,
    Alert,
    Image,
} from 'react-native';
import { logoutUser } from '../../services/authService';
import { AuthContext } from '../../contexts/AuthContext';
import Icon from 'react-native-vector-icons/Ionicons';

const { width } = Dimensions.get('window');
const MENU_WIDTH = width * 0.7;

const PatientDashboard = ({ navigation }) => {
    const { user, setUser } = useContext(AuthContext);
    const [menuOpen, setMenuOpen] = useState(false);
    const animatedValue = useRef(new Animated.Value(-MENU_WIDTH)).current;

    const openMenu = () => {
        setMenuOpen(true);
        Animated.timing(animatedValue, {
            toValue: 0,
            duration: 300,
            useNativeDriver: false,
        }).start();
    };

    const closeMenu = () => {
        Animated.timing(animatedValue, {
            toValue: -MENU_WIDTH,
            duration: 300,
            useNativeDriver: false,
        }).start(() => {
            setMenuOpen(false);
        });
    };

    const toggleMenu = () => {
        if (menuOpen) {
            closeMenu();
        } else {
            openMenu();
        }
    };

    const handleLogout = async () => {
        await logoutUser();
        setUser(null);
    };

    const confirmLogout = () => {
        Alert.alert(
            'Çıkış Yap',
            'Çıkış yapmak istediğinizden emin misiniz?',
            [
                { text: 'İptal', style: 'cancel' },
                { text: 'Evet', onPress: handleLogout },
            ],
            { cancelable: false }
        );
    };

    return (
        <SafeAreaView style={styles.container}>
            {/* Header */}
            <View style={styles.header}>
                <TouchableOpacity onPress={toggleMenu}>
                    <Icon name="menu" size={30} color="#000" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Hasta Paneli</Text>
            </View>

            {/* Overlay */}
            {menuOpen && (
                <TouchableWithoutFeedback onPress={closeMenu}>
                    <View style={styles.overlay} />
                </TouchableWithoutFeedback>
            )}

            {/* Side Menu */}
            <Animated.View
                style={[
                    styles.menu,
                    {
                        transform: [{ translateX: animatedValue }],
                    },
                ]}
            >
                <ScrollView contentContainerStyle={styles.menuContent}>
                    <TouchableOpacity
                        style={styles.menuItem}
                        onPress={() => {
                            toggleMenu();
                            navigation.navigate('UserProfile');
                        }}
                    >
                        <Icon name="person" size={20} color="#000" />
                        <Text style={styles.menuText}>Profilim</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={styles.menuItem}
                        onPress={() => {
                            toggleMenu();
                            navigation.navigate('TestResults');
                        }}
                    >
                        <Icon name="clipboard" size={20} color="#000" />
                        <Text style={styles.menuText}>Sonuçlarım</Text>
                    </TouchableOpacity>
                </ScrollView>
                <View style={styles.logoutContainer}>
                    <TouchableOpacity
                        style={styles.logoutButton}
                        onPress={confirmLogout}
                    >
                        <Icon name="log-out" size={20} color="#fff" />
                        <Text style={styles.logoutText}>Çıkış Yap</Text>
                    </TouchableOpacity>
                </View>
            </Animated.View>

            {/* Main Content */}
            <ScrollView contentContainerStyle={styles.content}>
                <Icon name="heart-circle-outline" size={100} color="#4CAF50" />
                <Text style={styles.welcomeText}>
                    Hoşgeldiniz, {user?.name || 'Kullanıcı'}!
                </Text>
                <Text style={styles.infoText}>
                    E-Laboratuvar Sistemi'ne hoş geldiniz. Test sonuçlarınızı kolayca görüntüleyebilirsiniz.
                </Text>
            </ScrollView>
        </SafeAreaView>
    );
};

export default PatientDashboard;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f9f9f9',
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 15,
        paddingTop: 50,
        backgroundColor: '#fff',
        elevation: 4,
    },
    headerTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        marginLeft: 10,
        flex: 1,
    },
    menu: {
        position: 'absolute',
        top: 0,
        bottom: 0,
        left: 0,
        width: MENU_WIDTH,
        backgroundColor: '#fff',
        elevation: 10,
        zIndex: 1000,
        borderRightWidth: 1,
        borderColor: '#ccc',
    },
    menuContent: {
        flexGrow: 1,
        justifyContent: 'flex-start',
        paddingTop: 50,
    },
    menuItem: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: 20,
        paddingHorizontal: 20,
        borderBottomWidth: 1,
        borderBottomColor: '#f1f1f1',
    },
    menuText: {
        fontSize: 16,
        marginLeft: 10,
        color: '#000',
    },
    logoutContainer: {
        borderTopWidth: 1,
        borderTopColor: '#f1f1f1',
        padding: 20,
    },
    logoutButton: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#ff4d4d',
        paddingVertical: 15,
        paddingHorizontal: 20,
        borderRadius: 5,
    },
    logoutText: {
        fontSize: 16,
        color: '#fff',
        marginLeft: 10,
        fontWeight: 'bold',
    },
    overlay: {
        position: 'absolute',
        top: 0,
        left: 0,
        width: width,
        height: '100%',
        backgroundColor: 'rgba(0,0,0,0.3)',
        zIndex: 500,
    },
    content: {
        flexGrow: 1,
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: 20,
        paddingVertical: 40,
    },
    welcomeText: {
        fontSize: 24,
        fontWeight: 'bold',
        marginTop: 20,
        color: '#333',
        textAlign: 'center',
    },
    infoText: {
        fontSize: 16,
        color: '#666',
        marginTop: 15,
        textAlign: 'center',
        lineHeight: 22,
    },

});
