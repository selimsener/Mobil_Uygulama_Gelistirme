// src/screens/Patient/TestDetailScreen.js
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, ScrollView, Dimensions } from 'react-native';
import { doc, getDoc, collection, query as firestoreQuery, orderBy, getDocs } from 'firebase/firestore';
import { db, auth } from '../../firebase';
import { VictoryChart, VictoryLine, VictoryScatter, VictoryAxis } from 'victory-native';
import Ionicons from 'react-native-vector-icons/Ionicons';

// Yardımcı Fonksiyonlar
const getStatusIcon = (status) => {
    switch (status) {
        case 'Yüksek':
            return 'arrow-up-circle';
        case 'Normal':
            return 'checkmark-circle';
        case 'Düşük':
            return 'arrow-down-circle';
        default:
            return 'help-circle';
    }
};

const getStatusColor = (status) => {
    switch (status) {
        case 'Yüksek':
            return 'red';
        case 'Normal':
            return 'green';
        case 'Düşük':
            return 'orange';
        default:
            return 'grey';
    }
};

const convertToMgL = (valueInGL) => valueInGL * 1000;

const determineDominantStatus = (evaluations) => {
    const statusCounts = evaluations.reduce((acc, evalItem) => {
        acc[evalItem.status] = (acc[evalItem.status] || 0) + 1;
        return acc;
    }, {});

    const dominantStatus = Object.keys(statusCounts).reduce((a, b) => (
        statusCounts[a] > statusCounts[b] ? a : b
    ));
    return dominantStatus;
};

const formatNumber = (num) => {
    return Number(num).toFixed(2).replace('.', ',');
};

// Grafik Bileşeni
const TestTrendChart = ({ testName }) => {
    const [chartData, setChartData] = useState(null);
    const userId = auth.currentUser.uid;

    useEffect(() => {
        loadChartData();
    }, [testName]);

    const loadChartData = async () => {
        const data = await prepareChartData(testName);
        setChartData(data);
    };

    const prepareChartData = async (testName) => {
        try {
            const resultsQuery = firestoreQuery(
                collection(db, 'users', userId, 'results'),
                orderBy('date', 'asc')
            );
            const querySnapshot = await getDocs(resultsQuery);
            const dataPoints = [];
            const labels = [];

            querySnapshot.forEach(doc => {
                const dataObj = doc.data();
                const date = dataObj.date.toDate().toLocaleDateString();
                const test = dataObj.tests.find(t => t.name === testName);
                if (test) {
                    const dominantStatus = determineDominantStatus(test.evaluations);
                    labels.push(date);
                    dataPoints.push({
                        x: date,
                        y: Number(test.value.toFixed(2)),
                        status: dominantStatus,
                    });
                }
            });

            return {
                dataPoints,
                labels
            };
        } catch (error) {
            console.error("Grafik verisi alınamadı: ", error);
            return {
                dataPoints: [],
                labels: []
            };
        }
    };

    if (!chartData || chartData.dataPoints.length === 0) {
        return <Text style={styles.noDataText}>Grafik için yeterli veri bulunmamaktadır.</Text>;
    }

    const chartWidth = Math.max(chartData.dataPoints.length * 50, Dimensions.get('window').width);

    return (
        <ScrollView horizontal>
            <VictoryChart
                width={chartWidth}
                height={220}
                domainPadding={{ x: 50, y: 20 }}
                padding={{ top: 20, bottom: 50, left: 50, right: 50 }}
            >
                <VictoryAxis
                    tickValues={chartData.labels}
                    tickFormat={(t) => t}
                    style={{
                        tickLabels: { angle: -45, fontSize: 10, padding: 15 },
                    }}
                />
                <VictoryAxis
                    dependentAxis
                    tickFormat={(x) => x}
                    style={{
                        tickLabels: { fontSize: 10, padding: 5 },
                    }}
                />
                <VictoryLine
                    data={chartData.dataPoints}
                    x="x"
                    y="y"
                    style={{
                        data: { stroke: "#1e90ff" },
                    }}
                />
                <VictoryScatter
                    data={chartData.dataPoints}
                    x="x"
                    y="y"
                    size={5}
                    style={{
                        data: {
                            fill: ({ datum }) => getStatusColor(datum.status),
                        }
                    }}
                />
            </VictoryChart>
        </ScrollView>
    );
};

const TestDetailScreen = ({ route }) => {
    const { testId } = route.params;
    const [testDetail, setTestDetail] = useState(null);
    const [loading, setLoading] = useState(true);
    const userId = auth.currentUser.uid;

    useEffect(() => {
        fetchTestDetail();
    }, []);

    const fetchTestDetail = async () => {
        setLoading(true);
        try {
            const docRef = doc(db, 'users', userId, 'results', testId);
            const docSnap = await getDoc(docRef);
            if (docSnap.exists()) {
                setTestDetail(docSnap.data());
            } else {
                alert('Belge bulunamadı!');
            }
        } catch (error) {
            alert('Veri alınamadı: ' + error.message);
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return <ActivityIndicator size="large" color="#4a90e2" style={styles.loader} />;
    }

    if (!testDetail) {
        return (
            <View style={styles.container}>
                <Text>Veri bulunamadı.</Text>
            </View>
        );
    }

    return (
        <ScrollView style={styles.container}>
            <Text style={styles.date}>{testDetail.date.toDate().toLocaleString()}</Text>
            {testDetail.tests.map(test => (
                <View key={test.name} style={styles.testContainer}>
                    <View style={styles.testHeader}>
                        <Ionicons
                            name="flask-outline"
                            size={16}
                            color="#333"
                            style={styles.flaskIcon}
                        />
                        <Text style={styles.testName}>
                            {test.name}:
                            <Text style={styles.testValue}>
                                {' '}
                                {parseFloat(test.value).toFixed(2)} g/L{' '}
                                {convertToMgL(parseFloat(test.value)).toFixed(2)} mg/L
                            </Text>
                        </Text>
                    </View>
                    {test.evaluations.map((evalItem, idx) => (
                        <View key={idx} style={styles.evaluationContainer}>
                            <View style={styles.statusRow}>
                                <Ionicons
                                    name={getStatusIcon(evalItem.status)}
                                    size={16}
                                    color={getStatusColor(evalItem.status)}
                                    style={styles.statusIcon}
                                />
                                <Text
                                    style={[
                                        styles.status,
                                        { color: getStatusColor(evalItem.status) },
                                    ]}
                                >
                                    {evalItem.status}
                                </Text>
                            </View>

                            <Text style={styles.guideLabel}>
                                Klavuz İsmi: <Text style={styles.guideValue}>{evalItem.guideName}</Text>
                            </Text>

                            <Text style={styles.referenceLabel}>
                                Referans Aralıkları:{' '}
                                <Text style={styles.referenceValue}>
                                    {formatNumber(evalItem.referenceMin)} - {formatNumber(evalItem.referenceMax)} {evalItem.unit}
                                </Text>
                            </Text>
                        </View>
                    ))}

                    <TestTrendChart testName={test.name} />
                </View>
            ))}
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f5f5f5',
        padding: 10,
    },
    loader: {
        flex: 1,
        justifyContent: 'center',
    },
    date: {
        fontSize: 18,
        fontWeight: 'bold',
        marginBottom: 15,
        textAlign: 'center',
    },
    testContainer: {
        backgroundColor: '#fff',
        padding: 15,
        marginBottom: 20,
        borderRadius: 10,
        elevation: 2,
    },
    testHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 10,
    },
    flaskIcon: {
        marginRight: 10,
    },
    testName: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#333',
    },
    testValue: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#333',
    },
    evaluationContainer: {
        marginTop: 10,
        padding: 10,
        backgroundColor: '#f9f9f9',
        borderRadius: 6,
    },
    statusRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 4,
    },
    statusIcon: {
        marginRight: 4,
    },
    status: {
        fontSize: 14,
        fontWeight: '600',
    },
    guideLabel: {
        fontSize: 14,
        fontWeight: '600',
        marginTop: 4,
        color: '#333',
    },
    guideValue: {
        fontWeight: '400',
        color: '#666',
    },
    referenceLabel: {
        fontSize: 14,
        fontWeight: '600',
        marginTop: 4,
        color: '#333',
    },
    referenceValue: {
        fontWeight: '400',
        color: '#666',
    },
    noDataText: {
        textAlign: 'center',
        color: '#888',
        marginTop: 10,
    },
});

export default TestDetailScreen;
