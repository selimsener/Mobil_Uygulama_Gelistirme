// ./src/screens/Patient/ChangePassword.js

import React, { useState } from 'react';
import {
    View,
    Text,
    TextInput,
    StyleSheet,
    Button,
    Alert,
    ActivityIndicator,
    ScrollView,
    TouchableOpacity
} from 'react-native';
import { getAuth, updatePassword, reauthenticateWithCredential, EmailAuthProvider } from 'firebase/auth';
import { validatePassword } from '../../utils/validators';

const ChangePassword = ({ navigation }) => {
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const [errors, setErrors] = useState({});
    const auth = getAuth();

    const validate = () => {
        const newErrors = {};
        if (!validatePassword(newPassword)) newErrors.newPassword = 'Şifre en az 6 karakterden oluşmalıdır.';
        if (newPassword !== confirmPassword) newErrors.confirmPassword = 'Yeni şifreler eşleşmiyor.';
        if (!currentPassword) newErrors.currentPassword = 'Mevcut şifrenizi giriniz.';
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleChangePassword = async () => {
        if (!validate()) {
            return;
        }

        setLoading(true);
        try {
            const user = auth.currentUser;
            const credential = EmailAuthProvider.credential(user.email, currentPassword);
            await reauthenticateWithCredential(user, credential);
            await updatePassword(user, newPassword);
            Alert.alert('Başarılı', 'Şifreniz başarıyla güncellendi.');
            navigation.goBack();
        } catch (error) {
            Alert.alert('Hata', 'Eski şifrenizi doğru girdiğinizden emin olun veya sonra tekrar deneyin.');
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return (
            <View style={styles.loadingContainer}>
                <ActivityIndicator size="large" color="#4a90e2" />
            </View>
        );
    }

    return (
        <ScrollView contentContainerStyle={styles.container}>
            <View style={styles.fieldContainer}>
                <Text style={styles.label}>Mevcut Şifre</Text>
                <TextInput
                    style={[styles.input, errors.currentPassword && styles.inputError]}
                    value={currentPassword}
                    onChangeText={setCurrentPassword}
                    secureTextEntry
                    placeholder="Mevcut şifrenizi girin"
                />
                {errors.currentPassword && <Text style={styles.error}>{errors.currentPassword}</Text>}
            </View>

            <View style={styles.fieldContainer}>
                <Text style={styles.label}>Yeni Şifre</Text>
                <TextInput
                    style={[styles.input, errors.newPassword && styles.inputError]}
                    value={newPassword}
                    onChangeText={setNewPassword}
                    secureTextEntry
                    placeholder="Yeni şifrenizi girin"
                />
                {errors.newPassword && <Text style={styles.error}>{errors.newPassword}</Text>}
            </View>

            <View style={styles.fieldContainer}>
                <Text style={styles.label}>Yeni Şifre (Tekrar)</Text>
                <TextInput
                    style={[styles.input, errors.confirmPassword && styles.inputError]}
                    value={confirmPassword}
                    onChangeText={setConfirmPassword}
                    secureTextEntry
                    placeholder="Yeni şifrenizi tekrar girin"
                />
                {errors.confirmPassword && <Text style={styles.error}>{errors.confirmPassword}</Text>}
            </View>

            <View style={styles.buttonContainer}>
                <TouchableOpacity style={styles.changeButton} onPress={handleChangePassword}>
                    <Text style={styles.buttonText}>Şifreyi Değiştir</Text>
                </TouchableOpacity>
            </View>
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        padding: 20,
        backgroundColor: '#f5f5f5',
        flexGrow: 1,
        justifyContent: 'start',
    },
    loadingContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#f5f5f5',
    },
    fieldContainer: {
        marginBottom: 20,
    },
    label: {
        fontSize: 16,
        marginBottom: 8,
        color: '#333',
        fontWeight: '600',
    },
    input: {
        borderWidth: 1,
        borderColor: '#ccc',
        padding: 12,
        borderRadius: 8,
        backgroundColor: '#fff',
        fontSize: 16,
    },
    inputError: {
        borderColor: 'red',
    },
    error: {
        color: 'red',
        marginTop: 5,
        fontSize: 14,
    },
    buttonContainer: {
        alignItems: 'center',
        marginTop: 10,
    },
    changeButton: {
        backgroundColor: '#4a90e2',
        paddingVertical: 15,
        paddingHorizontal: 40,
        borderRadius: 8,
        width: '100%',
        alignItems: 'center',
    },
    buttonText: {
        color: '#fff',
        fontSize: 16,
        fontWeight: '600',
    },
});

export default ChangePassword;
