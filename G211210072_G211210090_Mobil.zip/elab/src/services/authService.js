// services/authService.js
import { auth, db } from "../firebase";
import {
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    signOut
} from "firebase/auth";
import { doc, setDoc, getDoc } from "firebase/firestore";
import { storeUserData, clearUserData } from "./storageService";

export const registerUser = async ({ email, password, name, birthDate, tc }) => {
    const { user } = await createUserWithEmailAndPassword(auth, email, password);
    // Varsayılan rol: 'patient'
    const userDocRef = doc(db, "users", user.uid);
    await setDoc(userDocRef, {
        name,
        birthDate,
        tc,
        role: "patient",
        email
    });

    // Kullanıcı bilgilerini local storage'a yaz
    const userData = { uid: user.uid, role: "patient", name, birthDate, tc, email };
    await storeUserData(userData);

    return userData;
};

export const loginUser = async (email, password) => {
    const { user } = await signInWithEmailAndPassword(auth, email, password);

    // Kullanıcı rolü ve bilgilerinin Firestore'dan çekilmesi
    const userDocRef = doc(db, "users", user.uid);
    const userSnap = await getDoc(userDocRef);

    if (userSnap.exists()) {
        const userData = { uid: user.uid, ...userSnap.data() };
        await storeUserData(userData);
        return userData;
    } else {
        throw new Error("Kullanıcı bilgisi bulunamadı.");
    }
};

export const logoutUser = async () => {
    await signOut(auth);
    await clearUserData();
};
