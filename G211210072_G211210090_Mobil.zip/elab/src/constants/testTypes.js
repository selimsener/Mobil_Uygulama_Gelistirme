export const TEST_TYPES = [
    'IgA',
    'IgM',
    'IgG',
    'IgG1',
    'IgG2',
    'IgG3',
    'IgG4',
];
