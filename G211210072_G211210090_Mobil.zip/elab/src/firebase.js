// ./src/firebase.js

import { initializeApp } from "firebase/app";
import { initializeAuth, getReactNativePersistence } from "firebase/auth";
import ReactNativeAsyncStorage from "@react-native-async-storage/async-storage";

import { getFirestore } from "firebase/firestore";

const firebase = {
    apiKey: "AIzaSyBsqxoL31PIUaMJNP5nBYEOVENkVwIIC1s",
    authDomain: "elab-13cab.firebaseapp.com",
    projectId: "elab-13cab",
    storageBucket: "elab-13cab.firebasestorage.app",
    messagingSenderId: "8219337057",
    appId: "1:8219337057:web:32885bf82f47ef2c5c2520"
};


const app = initializeApp(firebase);

export const auth = initializeAuth(app, {
    persistence: getReactNativePersistence(ReactNativeAsyncStorage),
});

export const db = getFirestore(app);
