// ./src/utils/validators.js

export const validateEmail = (email) => {
    const re = /\S+@\S+\.\S+/;
    return re.test(email);
};

export const validatePassword = (password) => {
    return password.length >= 6;
};

export const validateName = (name) => {
    return name.trim().length > 0;
};

export const validateTC = (tc) => {
    // TC kimlik numarası örnek kontrolü, 11 haneli sayı
    return tc.length === 11 && /^\d+$/.test(tc);
};

export const validateDate = (date) => {
    return date instanceof Date && !isNaN(date);
};
