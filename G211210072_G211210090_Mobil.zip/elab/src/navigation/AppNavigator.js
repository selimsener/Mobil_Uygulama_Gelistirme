// navigation/AppNavigator.js
import React, { useContext } from "react";
import { NavigationContainer } from "@react-navigation/native";
import { AuthStack } from "./AuthStack";
import { AdminStack } from "./AdminStack";
import { PatientStack } from "./PatientStack";
import { AuthContext } from "../contexts/AuthContext";
import { ActivityIndicator, View } from "react-native";

export const AppNavigator = () => {
    const { user, initializing } = useContext(AuthContext);

    if (initializing) {
        return (
            <View style={{flex:1, justifyContent:'center', alignItems:'center'}}>
                <ActivityIndicator size="large" />
            </View>
        );
    }

    if (!user) {
        return (
            <NavigationContainer>
                <AuthStack />
            </NavigationContainer>
        );
    }


    if (user.role === "admin") {
        return (
            <NavigationContainer>
                <AdminStack />
            </NavigationContainer>
        );
    } else if (user.role === "patient") {
        return (
            <NavigationContainer>
                <PatientStack />
            </NavigationContainer>
        );
    }
};
