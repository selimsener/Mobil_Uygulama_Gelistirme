// navigation/AdminStack.js
import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import AdminDashboard from '../screens/Admin/AdminDashboard';
import GuideManagementScreen from '../screens/Admin/GuideManagementScreen';
import AddGuideScreen from '../screens/Admin/AddGuideScreen';
import GuideDetailScreen from '../screens/Admin/GuideDetailScreen';
import AddTestTypeScreen from '../screens/Admin/AddTestTypeScreen';
import TestTypeDetailScreen from '../screens/Admin/TestTypeDetailScreen';
import AddAgeGroupScreen from '../screens/Admin/AddAgeGroupScreen';

import EditGuideScreen from "../screens/Admin/EditGuideScreen";
import EditAgeGroupScreen from "../screens/Admin/EditAgeGroupScreen";

import AddTestResultScreen from "../screens/Admin/AddTestResultScreen";

import PatientManagementScreen from "../screens/Admin/PatientManagementScreen";
import PatientDetailScreen from "../screens/Admin/PatientDetailScreen";
import EditTestResultScreen from "../screens/Admin/EditTestResultScreen";
import QuickTestSearchScreen from "../screens/Admin/QuickTestSearchScreen";
import PatientAddScreen from "../screens/Admin/PatientAddScreen";
import AdminTestDetailScreen from "../screens/Admin/AdminTestDetailScreen";
import PatientUpdateScreen from "../screens/Admin/PatientUpdateScreen";
import QuickTestResultScreen from "../screens/Admin/QuickTestResultScreen";

const Stack = createStackNavigator();

export const AdminStack = () => {
    return (
        <Stack.Navigator>
            <Stack.Screen
                name="AdminDashboard"
                component={AdminDashboard}
                options={{headerShown :false}}
            />
            <Stack.Screen
                name="GuideManagement"
                component={GuideManagementScreen}
                options={{ title: 'Klavuz Yönetimi' }}
            />
            <Stack.Screen
                name="AddGuide"
                component={AddGuideScreen}
                options={{ title: 'Yeni Klavuz Ekle' }}
            />
            <Stack.Screen
                name="GuideDetail"
                component={GuideDetailScreen}
                options={{ title: 'Klavuz Detayları' }}
            />
            <Stack.Screen
                name="AddTestType"
                component={AddTestTypeScreen}
                options={{ title: 'Test Tipi Ekle' }}
            />
            <Stack.Screen
                name="TestTypeDetail"
                component={TestTypeDetailScreen}
                options={{ title: 'Test Tipi Detayları' }}
            />
            <Stack.Screen
                name="AddAgeGroup"
                component={AddAgeGroupScreen}
                options={{ title: 'Yaş Grubu Ekle' }}
            />
                <Stack.Screen
                name="EditGuide"
                component={EditGuideScreen}
                options={{ title: 'Klavuz Düzenle' }}
            />
            <Stack.Screen
                name="EditAgeGroup"
                component={EditAgeGroupScreen}
                options={{ title: 'Yaş Grubu Düzenle' }}
            />
                <Stack.Screen
                name="AddTestResult"
                component={AddTestResultScreen}
                options={{ title: 'Test Sonucu Ekle' }}
            />

            <Stack.Screen
                name="PatientManagement"
                component={PatientManagementScreen}
                options={{ title: 'Hasta Yonetimi' }}
            />
            <Stack.Screen
                name={"PatientDetail"}
                component={PatientDetailScreen}
                options={{ title: 'Hasta Detayları' }}
            />
                <Stack.Screen
                name="EditTestResult"
                component={EditTestResultScreen}
                options={{ title: 'Test Sonucu Düzenle' }}
            />
            <Stack.Screen
                name={"QuickTestSearch"}
                component={QuickTestSearchScreen}
                options={{ title: 'Hızlı Tetkit Arama' }}
            />
                <Stack.Screen
                    name={"TestDetail"}
                    component={AdminTestDetailScreen}
                    options={{ title: 'Tahlil Detayı' }}
                />
            <Stack.Screen
                name={"PatientAdd"}
                component={PatientAddScreen}
                options={{ title: 'Hasta Ekle' }}
            />
            <Stack.Screen
                name={"PatientUpdate"}
                component={PatientUpdateScreen}
                options={{ title: 'Hasta Güncelle' }}
            />
            <Stack.Screen
                name={"QuickTestResult"}
                component={QuickTestResultScreen}
                options={{ title: 'Hızlı Tahlil Sorgulama' }}
            />

        </Stack.Navigator>
    );
};
