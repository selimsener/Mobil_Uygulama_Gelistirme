// navigation/PatientStack.js
import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import PatientDashboard from '../screens/Patient/PatientDashboard';
import TestResultsScreen from '../screens/Patient/TestResultsScreen';
import  TestDetailScreen  from '../screens/Patient/TestDetailScreen';
import UserProfile from "../screens/Patient/UserProfile";
import ChangePassword from "../screens/Patient/ChangePassword";
import headerShownContext from "react-navigation-stack/src/vendor/utils/HeaderShownContext";


const Stack = createStackNavigator();

export const PatientStack = () => {
    return (
        <Stack.Navigator>
            <Stack.Screen
                name="PatientDashboard"
                component={PatientDashboard}
                options={{ headerShown: false }}
            />
            <Stack.Screen
                name={"TestResults"}
                component={TestResultsScreen}
                options={{ title: 'Sonuçlarım' }}
            />
            <Stack.Screen
                name={"TestDetail"}
                component={TestDetailScreen}
                options={{ title: 'Test Detayı' }}
            />
            <Stack.Screen
                name={"UserProfile"}
                component={UserProfile}
                options={{ title: 'Profilim' }}
            />
            <Stack.Screen
                name={"ChangePassword"}
                component={ChangePassword}
                options={{ title: 'Şifre Değiştir' }}
            />
        </Stack.Navigator>
    );
};
