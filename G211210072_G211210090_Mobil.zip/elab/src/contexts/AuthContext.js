// ./contexts/AuthContext.js

import React, { createContext, useEffect, useState } from "react";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "../firebase";
import { getUserData } from "../services/storageService";

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [initializing, setInitializing] = useState(true);

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
            if (firebaseUser) {
                try {
                    // Fetch user data from storageService
                    const storedUser = await getUserData(firebaseUser.uid);
                    setUser({ ...storedUser, uid: firebaseUser.uid }); // Ensure name field is included
                } catch (error) {
                    console.error("Failed to fetch user data:", error);
                }
            } else {
                setUser(null); // Set user to null on logout
            }
            setInitializing(false); // Initialization complete
        });

        return unsubscribe; // Clean up the auth listener
    }, []);

    const updateUser = (updatedData) => {
        setUser((prevUser) => ({ ...prevUser, ...updatedData }));
    };

    return (
        <AuthContext.Provider
            value={{
                user,
                setUser,
                updateUser,
                initializing,
            }}
        >
            {children}
        </AuthContext.Provider>
    );
};
